#include "main.h"
#include "phys.h"
#include "file.h"
#include "version.h"
#include "net.h"
#include "loop.h"

int main(int argc, char *argv[])
{
  int r;

  /* Is there a map file that we should load? */
  if (argc > 1){
    r = loadmap(argv[argc - 1]);
  }
  updateinterval = 0.1;
  setupnet();

  netthread = malloc(sizeof(pthread_t));

  /* Start the networking code as a new thread. */
  pthread_create(netthread,NULL,netloop,NULL);

  setupsignals();

  mainloop();

  return 0;
}
