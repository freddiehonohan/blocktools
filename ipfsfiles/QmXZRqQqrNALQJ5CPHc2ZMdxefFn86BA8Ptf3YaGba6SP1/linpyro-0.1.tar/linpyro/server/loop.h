void mainloop();
void *netloop(void *junk);
void setupsignals();
void cleanexit(int exittype);
extern int stop;
extern double updateinterval;

extern pthread_t *netthread;

/* How many nanoseconds there are per second */
#define NANOPERSEC 1000000000
