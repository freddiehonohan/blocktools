void dophys();
void physetup();

extern MAPUNIT *curmap;
extern MAPUNIT *oldmap;
extern MAPUNIT outside; /* The rest of the world */
extern long mapsizex;
extern long mapsizey;

extern pthread_mutex_t curmap_lock;
extern pthread_mutex_t oldmap_lock;
