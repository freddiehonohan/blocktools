void dofire();
