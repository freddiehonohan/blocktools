#include <math.h>
#include "main.h"
#include "phys.h"
#include "display.h"

/* A function to display the current map. */
void displaymap()
{
  int x,y;
  double temp;
  long double totalcal;
  
  printf("Mapsize x - %ld y - %ld\n",mapsizex,mapsizey);
  
  for (y = 0;y < mapsizey;y++){
    for (x = 0;x < mapsizex;x++){
      
      temp = curmap[(x * mapsizey) + y].totalcal / 
	curmap[(x * mapsizey) + y].calperc - K2C;

      temp = curmap[(x * mapsizey) + y].totalcal;

      /* Round temp */
      if (temp - floor(temp) >= 0.5) {
	temp = ceil(temp);
      }
      else if (temp - floor(temp) < 0.5) {
	temp = floor(temp);
      }
      
      if (temp < 10){
	printf("  %g ",temp);}
      else if (temp < 100){
	printf(" %g ",temp);}
      else{
	printf("%g ",temp);}

    }

    printf("\n");
  }

  totalcal = 0;

  for (x = 0;x < mapsizex;x++){
    for (y = 0;y < mapsizey;y++){

      totalcal += (curmap + ((x * mapsizey) + y))->totalcal;

    }
  }

  printf("totalcal - %Lg\n",totalcal);

}



