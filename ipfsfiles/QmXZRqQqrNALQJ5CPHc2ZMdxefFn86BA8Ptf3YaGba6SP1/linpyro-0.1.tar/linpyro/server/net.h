void donet();
void setupnet();
extern int portnum;
void check4new(void *junk);
 
