int addplayer(char *name);
void delplayer(int pnum);
void chgplayerinfo(int pnum,PLAYERINFO newinfo);

void getstartpos(MAP_VERTEX *pos);

extern pthread_mutex_t playerlist_lock;
extern PLAYERINFO *playerlist;
extern int numplayers;

extern MAP_VERTEX *s_points;
extern int s_pointsnum;
