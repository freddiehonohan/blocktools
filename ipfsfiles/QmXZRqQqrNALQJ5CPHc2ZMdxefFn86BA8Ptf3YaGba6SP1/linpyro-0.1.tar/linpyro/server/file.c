#include "main.h"
#include "phys.h"
#include <string.h>
#include <ctype.h>
#include "version.h"
#include "file.h"
#include "../shared/netpro.h"
#include "player.h"

char *stripndec(char *string,char replace);
int decodetype(char *tmpstring,UNITTYPE *tmptype);
void decodemap(FILE *fileptr,char *tmpstring);
void makemap();
long findunittype(long num);

/* The unit types array. */
UNITTYPE *unittypelist;
long numtypes = -1;

/* The temp map. Each num is a unit num, however you can't plug it into the
   unittypes array. You need to figure out the real index for unittypes. */
int *tmpmap = NULL;

/* Stuff describing the map. */
long xsize = 0;
long ysize = 0;
char *mapname = NULL;

/* The map loading functions. */

/* Loads a map file. filename is the filename of the map. If successful returns
   zero. Otherwise returns -1.
   */
int loadmap(char *filename)
{
  FILE *fileptr;
  int r;
  char tmpstring[25];
  long double tmpldouble;
  
  long tmpx;
  long tmpy;

  float version = -1; /* The file version. */

  /* Status args. */
  /* 0 means that we have not encountered the tag.
     1 means that we have encountered the tag and have got all of its options.
     2++ means that we are in the proccess of decoding the options of the flag.
         2 is the first flag, 3 the second etc.
     */
  int linpyro = 0,unittypes = 0,type = 0,map = 0,start = 0;

  /* The strings we look for. */

  /* The <linpyro> </linpyro> tags. */
  const char strlinpyro[] = "<linpyro";
  const char strlinpyroversion[] = "version=\"";
  const char strlinpyroend[] = "</linpyro>";

  /* The <unittypes> </unittypes> tags. */
  const char strunittypes[] = "<unittypes>";
  const char strunittypesend[] = "</unittypes>";

  /* The <map> </map> tags. */
  const char strmap[] = "<map";
  const char strmapname[] = "name=\"";
  const char strmapxsize[] = "xsize=";
  const char strmapysize[] = "ysize=";
  const char strmapend[] = "</map>";

  /* The <start> </start> tags. */
  const char strstart[] = "<start>";
  const char strstartend[] = "</start>";

  /* The <type> </type> tags. */
  const char strtype[] = "<type";
  const char strtypename[] = "name=";
  const char strtypenum[] = "num=";
  const char strtypeend[] = "</type>";


  printf("Loading %s\n",filename);

  /* Open the file. */
  fileptr = fopen(filename,"r");
  if (!fileptr) return -1;

  /* Start the reading loop. */
  for (;;)
    {

      /* Get the next string. */
      r = fscanf(fileptr,"%s",tmpstring);
      if (r == EOF || strlen(tmpstring) <= 0)
	{
	  break;
	}

      /* What was the string? */

      /* Decode the <linpyro> </linpyro> tags. */
      if (strcmp(tmpstring,strlinpyro) == 0)
	  linpyro = 2;
      else if (strncmp(strlinpyroversion,tmpstring,strlen(strlinpyroversion)) 
	       == 0 
	       && linpyro == 2)
	{
	  tmpldouble = atof(stripndec(tmpstring,' '));
	  linpyro = 1;
	  version = (float)tmpldouble;
	  /* Check if the version is not equal. */
	  if (version != fileversion)
	    {
	      fprintf(stderr,
		      "Error! File is version %f but we want %f.\n"
		      ,version,fileversion);
	      exit(EXIT_FAILURE);
	    }
	}
      else if (strcmp(tmpstring,strlinpyroend) == 0)
	{
	  linpyro = 0;
	}

      /* Decode the rest of the tags. Every tag depends on <linpyro> */
      else if (linpyro == 1)
	{

	  /* Decode the unittypes tags. */
	  if (strcmp(strunittypes,tmpstring) == 0)
	    unittypes = 1;
	  else if (strcmp(strunittypesend,tmpstring) == 0)
	    unittypes = 0;

	  /* Decode the <start> </start> tags. */
	  else if (strcmp(strstart,tmpstring) == 0)
	    start = 1;
	  else if (strcmp(strstartend,tmpstring) == 0)
	    start = 0;
	  /* Decode the <map> </map> tags. */
	  else if (strcmp(strmap,tmpstring) == 0)
	    map = 2;
	  else if (strcmp(strmapend,tmpstring) == 0)
	    map = 0;
	  /* Decode the inside of the <map> tag. */
	  else if (map == 2 && 
		   strncmp(strmapname,tmpstring,strlen(strmapname)) == 0)
	    {
	      map = 3;
	      mapname = (char *)malloc(strlen(tmpstring + strlen(strmapname)));
	      mapname = strcpy(mapname,(tmpstring + strlen(strmapname)));
	    }
	  else if (map == 3 &&
		   strncmp(strmapxsize,tmpstring,strlen(strmapxsize)) == 0)
	    {
	      map = 4;
	      xsize = atol(stripndec(tmpstring,' '));
	    }
 	  else if (map == 4 && 
		   strncmp(strmapysize,tmpstring,strlen(strmapysize)) == 0)
	    {
	      map = 1;
	      ysize = atol(stripndec(tmpstring,' '));
	    }

	  /* Decode whats inside the unittypes and map tags. */
	  else if (unittypes == 1 || map == 2 || map == 1)
	    {

	      /* The type tags, inside unittypes. */
	      if (strcmp(strtype,tmpstring) == 0)
		{
		  type = 2;
		  numtypes++;
		  /* Get some space for the unit type. */
		  unittypelist = 
		    realloc(unittypelist,sizeof(UNITTYPE) * (numtypes + 1));
		}
	      else if (strcmp(strtypeend,tmpstring) == 0)
		type = 0;
	      else if (type == 2)
		{
		  /* Now do the options inside the <type> tag. */
		  if (strncmp(tmpstring,strtypename,strlen(strtypename)) == 0)
		    {
		      /* Get some space for the name. */
		      (unittypelist + numtypes)->name = 
			(char *)malloc(strlen(tmpstring 
					      + strlen(strtypename)));
		      /* Record the name. */
		      (unittypelist + numtypes)->name = 
			strcpy((unittypelist + numtypes)->name,
			       (tmpstring + strlen(strtypename)));
		    }
		  else if (strncmp(tmpstring,strtypenum,strlen(strtypenum)) 
			   == 0)
		    {
		      (unittypelist + numtypes)->num =
			atoi(stripndec(tmpstring,' '));
		      type = 1;
		    }
		}

	      /* The stuff between the <map> and </map> tag. */
	      else if (map == 1 && type == 0 && start == 0)
		{
		  /* Decoding the <map> tags is a loop in itself. 
		     So we call another function to do it.
		     */ 
		  decodemap(fileptr,tmpstring);
		}
	      
	      /* Decode the stuff between the <type> and </type> tag. */
	      else if (map == 0 && type == 1 && start == 0)
		{
		  r = decodetype(tmpstring,(unittypelist + numtypes));
		  if (r == 0) type = 0;
		}

	      /* Decode the stuff between the <start> and </start> tag. */
	      else if (start == 1 && type == 0)
		{
		  r = sscanf(tmpstring,"%ld%*c%ld",&tmpx,&tmpy);

		  if (r >= 2){ 

		    s_pointsnum++;
		  
		    s_points = realloc(s_points,s_pointsnum * sizeof(MAP_VERTEX));

		    s_points[s_pointsnum - 1].x = tmpx;
		    s_points[s_pointsnum - 1].y = tmpy;

		  }
		  else
		    start = 0;
		}
	    }
	}
    }
  /* And close the file. */
  fclose(fileptr);

  /* Now make the map. */
  makemap();

  return 0;
}

/* Strips non-decimal characters from a string and replaces them.

   string is the string to strip.

   replace is the character to replace with.
   */
char *stripndec(char *string, char replace)
{
  int i;

  for (i = 0;i < strlen(string);i++)
    {
      /* Is the character a non-decimal? */
      if (isdigit((int)*(string + i)) == 0 && *(string + i) != '.')
	*(string + i) = replace;
    }
  
  return string;
}

/* Decodes something between a <type> and </type> tag. */
/* Returns 1 if successfull, 0 if it encounters a </type> tag. 
 
   tmpstring is the string to decode.
   tmptype is a pointer to the type you want changed.

*/
int decodetype(char *tmpstring,UNITTYPE *tmptype)
{

  const char strtemp[] = "temp=";
  const char strcocon[] = "cocon=";
  const char strcalperc[] = "calperc=";
  const char strignitionpoint[] = "ignitionpoint=";
  const char strfuellevel[] = "fuellevel=";
  const char strburnspeed[] = "burnspeed=";
  const char strcalperf[] = "calperf=";
  const char strblock[] = "block";
  const char end[] = "</type>";

  /* This figures out what to do with tmpstring. */
  if (strncmp(strtemp,tmpstring,strlen(strtemp)) == 0)
    tmptype->temp = atoi(stripndec(tmpstring,' '));
  else if (strncmp(strcocon,tmpstring,strlen(strcocon)) == 0)
    tmptype->cocon = atof(stripndec(tmpstring,' '));
  else if (strncmp(strcalperc,tmpstring,strlen(strcalperc)) == 0)
    tmptype->calperc = atof(stripndec(tmpstring,' '));
  else if (strncmp(strignitionpoint,tmpstring,strlen(strignitionpoint)) == 0)
    tmptype->ignitionpoint = atol(stripndec(tmpstring,' '));
  else if (strncmp(strfuellevel,tmpstring,strlen(strfuellevel)) == 0)
    tmptype->fuellevel = atof(stripndec(tmpstring,' '));
  else if (strncmp(strburnspeed,tmpstring,strlen(strburnspeed)) == 0)
    tmptype->burnspeed = atof(stripndec(tmpstring,' '));
  else if (strncmp(strcalperf,tmpstring,strlen(strcalperf)) == 0)
    tmptype->calperf = atof(stripndec(tmpstring,' '));
  else if (strncmp(strblock,tmpstring,strlen(strblock)) == 0)
    tmptype->block = 1;
  else if (strcmp(end,tmpstring) == 0)
    return 0;

  return 1;
}

/* This function decodes the stuff between the <map> and </map> tags. 
   
   fileptr is the file to decode.

   tmpstring is the first string to decode. Then decodemap will start reading
   it's own values.
   */
void decodemap(FILE *fileptr,char *tmpstring)
{
  const char strend[] = "</map>";
  const char strr[] = "<r>";
  int r = 1;
  int firstrun = 0;
  long x = 0;
  long y = 0;
  size_t tmpsize;

  /* Allocate space for tmpmap. */
  tmpsize = (size_t)(((xsize - 1) * ysize) + ysize);
  tmpmap = (int *)malloc(sizeof(int) * tmpsize);
  if (!tmpmap){
    fprintf(stderr,"Error! Couldn't allocate tmpmap.\n");
    exit(EXIT_FAILURE);
  }

  for (;;)
    {

      /* Get the next string. */
      if (firstrun == 1) r = fscanf(fileptr,"%s",tmpstring);
      firstrun = 1;
      if (r == EOF || strlen(tmpstring) <= 0)
	{
	  return;
	}
  
      /* Figure out what to do with the string. */
      if (strcmp(strend,tmpstring) == 0) 
	return;
      else if (strcmp(strr,tmpstring) == 0)
	{
	  y++;
	  x = 0;
	}
      else
	{
	  /* Put the value in it's place. */
	  *(tmpmap + ((x * ysize) + y)) = atoi(tmpstring);
	  x++;
	}
    }
}

/* This function converts all of tmpmap to the maps that we are going to use. 
   It returns nothing and expects nothing except a valid map in tmpmap. */
void makemap()
{
  long x = 0,y = 0,i,i2;
  size_t size;

  /* The first thing we do is allocate space for the map.
     This code used to be in phys.c but has been moved over here. 
     */
  mapsizex = xsize;
  mapsizey = ysize;

  printf("Decoding map...\n");

  /* Figure out the maximum possible index plus one. Thats why I don't have
     (mapsizey - 1) and instead just have mapsizey. This has been the source
     of a few really strange bugs.
     */
  size = (size_t)(((mapsizex - 1) * mapsizey) + mapsizey);
  curmap = malloc(sizeof(MAPUNIT) * size);
  if (!curmap){
    fprintf(stderr,"Couldn't allocate memory for curmap, exiting.\n");
    exit(EXIT_FAILURE);
  }
  printf("Allocated curmap\n");
  oldmap = (MAPUNIT *)malloc(sizeof(MAPUNIT) * size);
  if (!oldmap){
    fprintf(stderr,"Couldn't allocate memory for oldmap, exiting.\n");
    exit(EXIT_FAILURE);
  }
  printf("Allocated oldmap\n");

  /* Now conver tmpmap into oldmap by looking up all the values in unittypelist
     and putting them into oldmap.

     This function uses super slow sequential searches. It's *gotta* be 
     optimized. Binary search? 
     */
  printf("Setting up map");
  for (x = 0;x < mapsizex;x++){
    printf(".");
    for (y = 0;y < mapsizey;y++){

      /* Find the unittypelist index we need. */
      i = findunittype(*(tmpmap + ((x * mapsizey) + y)));

      /* Do we have a valid unittype? */
      if (i == -1)
	{
	  fprintf(stderr,"Error! Invalid unittype in map! unittype = %d\n",
		  *(tmpmap + ((x * mapsizey) + y)));
	  exit(EXIT_FAILURE);
	}

      /* Now put in all of the varibles from unittype into the correct 
	 positions in oldmap. */
      i2 = (x * mapsizey) + y;
      oldmap[i2].calperc = unittypelist[i].calperc;
      oldmap[i2].ignitionpoint = unittypelist[i].ignitionpoint;
      oldmap[i2].calperf = unittypelist[i].calperf;
      oldmap[i2].fuellevel = unittypelist[i].fuellevel;
      oldmap[i2].burnspeed = unittypelist[i].burnspeed;
      oldmap[i2].cocon = unittypelist[i].cocon;
      oldmap[i2].block = unittypelist[i].block;

      /* The totalcal is special. The map file only tells us the temperature. 
	 We have to figure out totalcal. */
      (oldmap + i2)->totalcal = 
	(long double)(unittypelist + i)->temp * (oldmap + i2)->calperc;

    }
  }

  printf("\n");

  /* One last thing. We need to set the outside var, or else. ;) */
  i = findunittype(0);
  if (i == -1)
    {
      fprintf(stderr,"Error! No outside type defined in map. Quiting.\n");
      exit(EXIT_FAILURE);
    }

  /* And set everthing for outside. */
  outside.calperc = (unittypelist + i)->calperc;
  outside.ignitionpoint = (unittypelist + i)->ignitionpoint;
  outside.calperf = (unittypelist + i)->calperf;
  outside.fuellevel = (unittypelist + i)->fuellevel;
  outside.burnspeed = (unittypelist + i)->burnspeed;
  outside.cocon = (unittypelist + i)->cocon;

  /* The totalcal is special. The map file only tells us the temperature. 
	 We have to figure out the totalcal. */
  outside.totalcal = 
    (unittypelist + i)->temp * outside.calperc;

}

/* Finds the names unittype in unittypelist. If num isn't valid return
   -1
*/
long findunittype(long num)
{

  long i;

  for (i = 0; i <= numtypes; i++)
    {
      if ((unittypelist + i)->num == num) return i;
    }

  return -1;
}
