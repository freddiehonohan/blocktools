#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "../shared/phydefs.h"
#include "loop.h"

/* Vertex type. Used in the starting point array. */
typedef struct map_vertex {
  long x;
  long y;
} MAP_VERTEX;

