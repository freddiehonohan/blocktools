/* Network code for the server. */

#include "net.h"
#include "main.h"
#include "phys.h"
#include "file.h"
#include "version.h"
#include "../shared/netpro.h"
#include "../shared/checksum.h"
#include "player.h"
#include "scorefunc.h"

/* Network includes. */
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>

#include <time.h>

#define BLEN 1024
void clearbuff(char *buff,int len);
void cleanconsock();
void totsend(int sock,void *buff,int len,int op);
int  totrecv(int sock,void *buff,int len,int op);
int check4err(int *x,int *y,int sock);

void *checksock(void *sock);

int portnum = 3140; /* Default port used */
int backlog = 10; /* Backlog for listen. */
int timeout = 300; /* Timeout in updateintervals. */

/* Address info for me. */
struct sockaddr_in my_addr;

/* The socket we listen on. */
int sockfd;

/* Strings needed for the protocol handling. */

/* General functions. */
const char strterm = ';';
const char strversion[] = "version;";
const char strprotocolversion[] = "protocolversion;";
const char strclose[] = "close;";

/* Map Request Functions */
const char strgetmapinfo[] = "getmapinfo;";
const char strgetmap[] = "getmap;";
const char strgetallmap[] = "getallmap;";

/* Player functions. */
const char strgetplayerinfo[] = "getplayerinfo;";
const char strsetplayerinfo[] = "setplayerinfo;";
const char strlogin[] = "login;";

/* Player actions. */
const char strsetfire[] = "setfire;";
 
/* Sets up the port that we listen on. */
void setupnet()
{
  /* Make a socket for ourselves. */
  sockfd = socket(AF_INET, SOCK_STREAM, 0);

  if (sockfd == -1){
    perror("socket");
    exit(EXIT_FAILURE);
  }

  /* Setup my_addr */
  my_addr.sin_family = AF_INET;         /* host byte order */
  my_addr.sin_port = htons(portnum);     /* short, network byte order */
  my_addr.sin_addr.s_addr = INADDR_ANY; /* auto-fill with my IP */
  bzero(&(my_addr.sin_zero), 8);        /* zero the rest of the struct */

  /* Bind the socket to a port. */
  if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr))
      == -1) {
    perror("bind");
    exit(EXIT_FAILURE);
  }

  /* Start listening to the socket. */
  if (listen(sockfd, backlog) == -1) {
    perror("listen");
    exit(1);
  }

}

/* Checks for new connections. */
void check4new(void *junk){
  int new_fd; /* Temp socket. */
  struct sockaddr_in tmpaddr; /* Temp address. */
  int sinsize = sizeof(struct sockaddr_in);
  void *tmpvoid;
  pthread_attr_t thattr;
  pthread_t *newthread;
  int r;

  /* Make the thread attr object. */
  r = pthread_attr_init(&thattr);
  r = pthread_attr_setdetachstate(&thattr,PTHREAD_CREATE_DETACHED);

  /* Now check for new connections. */
  new_fd = accept(sockfd, (struct sockaddr *)&tmpaddr, &sinsize);
  if (new_fd != -1){
    /* Looks like we have a connection. Make a new thread for it. */

    newthread = malloc(sizeof(pthread_t));

    tmpvoid = (void *)&new_fd;

    pthread_create(newthread,&thattr,checksock,tmpvoid);
    sleep(1);

  }
}

/* Checks a preexisting connection. */
void *checksock(void *sock){
  int r,r2,i;
  long x,y;
  int nosend = 0;
  int consock;
  char *cmdline;
  int ourplayer = -1;
  int damage;
  long double totalheat;

  time_t lasttime;

  long double tmpdlong;

  /* Temp firstmap, updatemap and netoverhead vars. */
  FIRSTMAP    tmpfirstmap;
  UPDATEMAP   tmpupdatemap;
  NETOVERHEAD tmpoverhead;
  PLAYERINFO  tmpplayerinfo;
  
  char tmpbuff[BLEN]; /* Temp buffer for send and recv. */
  

  consock = *((int *)sock);

  /* Create cmdline. */
  cmdline = malloc(1);
  *cmdline = '\000';

  lasttime = time(NULL);

  while (1){


    /* Do time critical stuff, currently just reducing the health of the 
       player if things are too toasty. :) 
       */
    if (lasttime < (time(NULL) + 1)){
      lasttime = time(NULL);

      if (ourplayer > -1){

	/* Are things a bit hot? */
	i = oldmap[playerlist[ourplayer].x * mapsizey + playerlist[ourplayer].y].totalcal / oldmap[playerlist[ourplayer].x * mapsizey + playerlist[ourplayer].y].calperc;

	if (i > 110 + K2C){
	  if (playerlist[ourplayer].health > 0){
	    damage = (int)((i - K2C - 110) / 10);
	    playerlist[ourplayer].health -= damage;

	    /* Give the players who started the fire some points. */
	    pthread_mutex_lock(&playerlist_lock);

	    /* Find the total heat added by players. */
	    totalheat = 0;
	    for (i = 0; i <=topslot; i++){
	      totalheat += oldmap[playerlist[ourplayer].x * mapsizey + playerlist[ourplayer].y].sourcequan[i];
	    }

#if SCOREDEBUG
	    printf("totalheat = %g - %d\n",(float)totalheat,consock);
#endif

	    /* Each player gets in points the damage done to the other player.
	       However this damage is then reduced by figuring out the relative
	       amount the player helped in starting the fire. 
	       */
	    for (i = 0; i <= topslot - 10; i++){

#if SCOREDEBUG
	      printf(" heatsource[%d] = %d - %d\n",i,oldmap[playerlist[ourplayer].x * mapsizey + playerlist[ourplayer].y].heatsource[i],consock);
	      printf(" sourcequan[%d] = %g - %d\n",i,(float)oldmap[playerlist[ourplayer].x * mapsizey + playerlist[ourplayer].y].sourcequan[i],consock);
#endif

	      /* Is the player valid and not ourself? */
	      if (oldmap[playerlist[ourplayer].x * mapsizey + playerlist[ourplayer].y].heatsource[i] - 1 != ourplayer && oldmap[playerlist[ourplayer].x * mapsizey + playerlist[ourplayer].y].heatsource[i] != freeslot){

		/* Give the player some points. */
		playerlist[oldmap[playerlist[ourplayer].x * mapsizey + playerlist[ourplayer].y].heatsource[i] - 1].score += (oldmap[playerlist[ourplayer].x * mapsizey + playerlist[ourplayer].y].sourcequan[i] / totalheat) * damage;
	      }
	    }
	    pthread_mutex_unlock(&playerlist_lock);
	  }
	}
      }
    }

    /* Get a command the client has transmitted to us. */
    clearbuff(tmpbuff,BLEN);
    r = r2 = 0;
    while (1){
      r = recv(consock,&tmpbuff[r2],1,0);
#if DEBUG2
      printf("r = %d r2 = %d char = %c - %d\n",r,r2,tmpbuff[r2],consock);
#endif
      if (r < 1){
#if DEBUG2
	printf("pthread_exit - %d\n",consock);
#endif
	if (ourplayer != -1){
	  delplayer(ourplayer);
	}
	pthread_exit(NULL);
      }
      if (tmpbuff[r2] == strterm){
#if DEBUG2
	printf("strterm - %d\n",consock);
#endif
        r2 = 1;
	break;
      }
      r2 += r;
    }

    /* Did the client give us anything new? */
    if (r2 > 0){
      /* Put add what the client has given us to cmdline. */
      
      /* Allocate space for the new string. The + 1 gives space for the
	 null terminator. */
      cmdline = realloc(cmdline,strlen(cmdline) + 
			       strlen(tmpbuff) + 1);

      /* Now concatenate the two strings. */
      cmdline = strcat(cmdline,tmpbuff);

    } 

    /* Now proccess the command. */
    nosend = 0;

#if DEBUG
    printf("cmdline = %s tmpbuff = %s - %d\n",cmdline,tmpbuff,consock);
#endif

    /* Does the string end in strterm? */
    if (*(cmdline + (strlen(cmdline) - 1)) == strterm){

      clearbuff(tmpbuff,BLEN);

      /* Figure out what to do with the command. */

      /* General functions. */
      if (strcmp(strversion,cmdline) == 0)
	sprintf(tmpbuff,"%f",fversion);
      else if (strcmp(strprotocolversion,cmdline) == 0)
	sprintf(tmpbuff,"%f",netpro);
      else if (strcmp(strclose,cmdline) == 0){

#if DEBUGTHREADS
	printf("closing connection - %d\n",consock);
#endif

	/* Close the connection. */
	free(cmdline); /* Free the space used by cmdline. */
#if DEBUG
	printf("closing consock - %d\n",consock);
#endif
	close(consock); /* Close the connection. */

#if DEBUGTHREADS
	printf("closing thread\n");
#endif

	if (ourplayer != -1){
	  delplayer(ourplayer);
	}

	pthread_exit(NULL);

      }

      /* Map Request Functions. */
      else if (strcmp(strgetmapinfo,cmdline) == 0)
	sprintf(tmpbuff,"%ld %ld \"%s\"",mapsizex,mapsizey,mapname);
      
      /* getmap function. */
      else if (strcmp(strgetmap,cmdline) == 0){

#if DEBUGLOCKS
	printf("locking oldmap - %d",consock);
#endif

	pthread_mutex_lock(&oldmap_lock);

#if DEBUGLOCKS
	printf(" locking oldmap done - %d\n",consock);
#endif

	nosend = 1;
	for (x = 0; x < mapsizex; x++){
	  for (y = 0; y < mapsizey; y++){

	    /* Create the firstmap temp var. */
	    tmpupdatemap.neto.type = TYPE_DATA;
	    tmpupdatemap.neto.x = x;
	    tmpupdatemap.neto.y = y;
	    tmpupdatemap.totalcal = oldmap[x * mapsizey + y].totalcal;
	    tmpupdatemap.fuellevel = oldmap[x * mapsizey + y].fuellevel;

	    /* This *must* be set to zero! The client sets checksum to zero 
	       when it calculates the checksum. We must do the same. */
	    tmpupdatemap.neto.checksum = 0;

	    /* Create the checksum. */
	    tmpupdatemap.neto.checksum = 
	      checksum(&tmpupdatemap,sizeof(UPDATEMAP));

	    totsend(consock,&tmpupdatemap,sizeof(UPDATEMAP),0);
	  }
	}

	/* Send the TYPE_DONE packet. */
	tmpupdatemap.neto.type = TYPE_DONE;
	totsend(consock,&tmpupdatemap,sizeof(UPDATEMAP),0);

#if DEBUGLOCKS
	printf("unlocking oldmap - %d",consock);
#endif

	pthread_mutex_unlock(&oldmap_lock);

#if DEBUGLOCKS
	printf(" unlocking oldmap done - %d\n",consock);
#endif

      }

      /* getallmap function. */
      else if (strcmp(strgetallmap,cmdline) == 0){

	pthread_mutex_lock(&oldmap_lock);

	nosend = 1;
	for (x = 0; x < mapsizex; x++){
	  for (y = 0; y < mapsizey; y++){

	    /* Create the firstmap temp var. */
	    tmpfirstmap.neto.type = TYPE_DATA;
	    tmpfirstmap.neto.x = x;
	    tmpfirstmap.neto.y = y;
	    tmpfirstmap.totalcal = oldmap[x * mapsizey + y].totalcal;
	    tmpfirstmap.cocon = oldmap[x * mapsizey + y].cocon;
	    tmpfirstmap.calperc = oldmap[x * mapsizey + y].calperc;
	    tmpfirstmap.ignitionpoint = oldmap[x * mapsizey + y].ignitionpoint;
	    tmpfirstmap.fuellevel = oldmap[x * mapsizey + y].fuellevel;
	    tmpfirstmap.calperf = oldmap[x * mapsizey + y].calperf;
	    tmpfirstmap.burnspeed = oldmap[x * mapsizey + y].burnspeed;
	    tmpfirstmap.block = oldmap[x * mapsizey + y].block;

	    /* This *must* be set to zero! The client sets checksum to zero 
	       when it calculates the checksum. We must do the same. */
	    tmpfirstmap.neto.checksum = 0;

	    /* Create the checksum. */
	    tmpfirstmap.neto.checksum = 
	      checksum(&tmpfirstmap,sizeof(FIRSTMAP));

	    totsend(consock,&tmpfirstmap,sizeof(FIRSTMAP),0);
	  }
	}

	/* Send the TYPE_DONE packet. */
	tmpfirstmap.neto.type = TYPE_DONE;
	totsend(consock,&tmpfirstmap,sizeof(FIRSTMAP),0);

	pthread_mutex_unlock(&oldmap_lock);

      }

      /* Player commands. */
      else if (strcmp(strgetplayerinfo,cmdline) == 0){

	pthread_mutex_lock(&playerlist_lock);

	nosend = 1;
	for (i = 0; i < numplayers; i++){

	  playerlist[i].neto.type = TYPE_DATA;

	  /* This *must* be set to zero! The client sets checksum to zero 
	     when it calculates the checksum. We must do the same. */
	  playerlist[i].neto.checksum = 0;

	  /* Create the checksum. */
	  playerlist[i].neto.checksum = 
	    checksum(&playerlist[i],sizeof(PLAYERINFO));

	  totsend(consock,&playerlist[i],sizeof(PLAYERINFO),0);
	}

	/* Send the TYPE_DONE packet. */
	tmpplayerinfo.neto.type = TYPE_DONE;
	totsend(consock,&tmpplayerinfo,sizeof(PLAYERINFO),0);

	pthread_mutex_unlock(&playerlist_lock);

      }
      else if (strcmp(strsetplayerinfo,cmdline) == 0){

	/* Send the ready packet. */
	tmpoverhead.type = TYPE_READY;
	totsend(consock,&tmpoverhead,sizeof(NETOVERHEAD),0);

	/* Wait for the player packet. */
	r = totrecv(consock,&tmpplayerinfo,sizeof(PLAYERINFO),0);

#if DEBUGPLAYERS
	printf("Changing info on player %d - %d\n",
	       tmpplayerinfo.num,consock);
#endif


	/* Set the info. */
        chgplayerinfo(tmpplayerinfo.num,tmpplayerinfo);

	/* Send the done packet. */
	tmpoverhead.type = TYPE_DONE;
	totsend(consock,&tmpoverhead,sizeof(NETOVERHEAD),0);

      }
      else if (strcmp(strlogin,cmdline) == 0){

	/* Send the ready packet. */
	tmpoverhead.type = TYPE_READY;
	totsend(consock,&tmpoverhead,sizeof(NETOVERHEAD),0);

	/* Wait for the player packet. */
	r = totrecv(consock,&tmpplayerinfo,sizeof(PLAYERINFO),0);

#if DEBUGPLAYERS
	printf("Adding player %s - %d\n",tmpplayerinfo.name,consock);
#endif

	/* Add the player. */
	ourplayer = addplayer(tmpplayerinfo.name);

	/* Send the done packet. */
	tmpoverhead.x = ourplayer;
	tmpoverhead.type = TYPE_DONE;
	totsend(consock,&tmpoverhead,sizeof(NETOVERHEAD),0);

      }
      else if (strcmp(strsetfire,cmdline) == 0){

	/* Is the player not dead? */
	if (playerlist[ourplayer].health > 0){
	  
#if DEBUG2
	  printf("setting fire at %ld - %ld\n",playerlist[ourplayer].x,playerlist[ourplayer].y);
#endif

	  /* Set a fire. Really simple. :) Just gotta lock the map... */
	  pthread_mutex_lock(&oldmap_lock);

	  tmpdlong = 100;
	  oldmap[playerlist[ourplayer].x * mapsizey + playerlist[ourplayer].y]
	    .totalcal += tmpdlong;

	  /* Keep track of who started what fires. */
	  addheatfromplayer(&oldmap[playerlist[ourplayer].x * mapsizey 
			+ playerlist[ourplayer].y],tmpdlong,ourplayer + 1);

	  pthread_mutex_unlock(&oldmap_lock);
	}
      }
      
      if (!nosend){
	/* Now send the buffer. */
	r = send(consock,tmpbuff,strlen(tmpbuff),0);
      }

      /* Now that we're done go and clear cmdline. */
      free(cmdline);
      cmdline = malloc(sizeof(char));
      *cmdline = '\000';
    }
  }

  return NULL;
}

/* Insures all of a packet is sent. */
void totsend(int sock,void *buff,int len,int op){
  int r = 0;
  int rlen = 0;
  int fl;

  fl = fcntl(sock,F_GETFL);

  /* Make the socket blocking. */
  fcntl(sock,F_SETFL,0);

  while (rlen < len){

    r = send(sock,(buff + rlen),len - rlen,op);

    if (r > 0)
      rlen += r;
  }

  fcntl(sock,F_SETFL,fl);
}

int totrecv(int sock,void *buff,int len,int op){
  int r = 0;
  int rlen = 0;
  int fl;

  fl = fcntl(sock,F_GETFL);

  /* Make the socket blocking. */
  fcntl(sock,F_SETFL,0);

  while (rlen < len){

    r = recv(sock,(buff + rlen),len - rlen,op);

    if (r > 0)
      rlen += r;
  }

  fcntl(sock,F_SETFL,fl);

  return rlen;
}

/* Checks for and error packet. */

/* Returns 1 if error, 0 if no error. If error x and y are changed to the x and
   y of the error packet.
   */
int check4err(int *x,int *y,int sock){
  NETOVERHEAD tmpoverhead;
  int r;

  r = recv(sock,&tmpoverhead,sizeof(NETOVERHEAD),0);

  if (r == sizeof(NETOVERHEAD)){
    if (tmpoverhead.type == TYPE_ERR){
      *x = tmpoverhead.x;
      *y = tmpoverhead.y;
      return 1;
    }
  }
  return 0;
}

/* Clears a buffer. */
void clearbuff(char *buff,int len)
{
  int i;

  for (i = 0; i < len;i++){
    *(buff + i) = '\000';
  }
}
