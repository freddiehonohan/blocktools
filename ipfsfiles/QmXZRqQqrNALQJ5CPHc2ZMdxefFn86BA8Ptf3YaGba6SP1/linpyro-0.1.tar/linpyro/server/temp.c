#include "main.h"
#include "temp.h"
#include "phys.h"
#include "scorefunc.h"

/* Does everything needed for one cycle of the temperature simulation. */
void dotemp()
{
  long x, y;

  /* Syncronize curmap and oldmap. */
  for (x = 0;x < mapsizex;x++){
    for (y = 0;y < mapsizey;y++){
      *(curmap + ((x * mapsizey) + y)) = *(oldmap + ((x * mapsizey) + y));
    }
  }

  /* Just go through all of the x and y coords and figure out what the new
     temperature should be for each MAPUNIT.

     The only tricky bit is remembering to scale cocon to the current 
     updateinterval. */
  for (x = 0;x < mapsizex;x++){
    for (y = 0;y < mapsizey;y++){
 
      /* Now distribute excess calories between the adjacent mapunits */      

      /* The formula we use assumes that a fixed percentage of the total
	 calories is available to each mapunit. The exact formula is:

	 reccal is the of calories currently in reciving mapunit.

	 srccal is the amount of calories currently in the source mapunit.

	 cocon is the total coefficient of conductivity between rec and src.

	 rectemp is the current temperature in the reciving mapunit.

	 srctemp as above but for source mapunit.

	 x is the share of calories this mapunit should get. It's found by
	 another function.

	 To calculate the new amount of calories in the reciving and source
	 mapunits use these two formulas:

	 reccal = (cocon * ((srctemp - rectemp) / 2)) * x 
                 
	 srccal = reccal - oldreccal

	 Note that both of these formulas assume the reciving mapunit has 
	 fewer calories then the source mapunit.
      */

      /* Call another function to distribute the calories. */
      distribcal(x,y);
    }
  }

  /* Now simulate energy coming in from the outside. */

  /* Add mapunits on the edge are checked in the sequence:

     111111
     3****2
     3****2
     3****2
     444444
     
     Everything else is just like the normal temperature simulation. 

     Note that the corners have energy added to them twice, they have two
     sides adjacent to the outside.
     */

  /* First side. */
  y = -1;
  for (x = 0;x < mapsizex;x++){
    distribcal(x,y);
  }

  /* Second side. */
  x = mapsizex;
  for (y = 0; y < mapsizey;y++){
    distribcal(x,y);
  }

  /* Third side. */
  x = -1;
  for (y = 0; y < mapsizey;y++){
     distribcal(x,y);
  }

  /* Forth side. */
  y = mapsizey;
  for (x = 0; x < mapsizex;x++){
     distribcal(x,y);
  }

}

/* Distributes the exccess calories of a mapunit. Note that the mapunit
   can be outside of the map. If so distribcal will assume the mapunit 
   should be outside. Any adjacent mapunits inside the map will be correctly
   mapped.
*/
void distribcal(long x, long y)
{

  typedef struct vertex 
  {
    long x;
    long y;
  } VERTEX;

  int t,i;
  VERTEX reqpos[8];
  long double wantedcal = 0,temp,cocon,srctemp,rectemp;
  MAPUNIT *src,*rec;
  long recx, recy;
  long double reqcal[8];

  /* Figure out what src should be. */ 
  if (x < 0 || y < 0 || x > (mapsizex - 1) || y > (mapsizey - 1)){
    src = &outside;
  }
  else {
    src = (oldmap + ((x * mapsizey) + y));
  }

  /* Find the x, y coords for each rec mapunit. */
  for (t = 0;t <= 7;t++){

    /* Clear reqpos and reqcal */
    reqpos[t].x = 0;
    reqpos[t].y = 0;
    reqcal[t] = 0;

      /* Figure out the x,y coords for the rec mapunit. */
    switch (t){
    case 0:
      recx = x + 1;
      recy = y;
      break;
    case 1:
      recx = x + 1;
      recy = y + 1;
      break;
    case 2:
      recx = x;
      recy = y + 1;
      break;
    case 3:
      recx = x - 1;
      recy = y + 1;
      break;
    case 4:
      recx = x - 1;
      recy = y;
      break;
    case 5:
      recx = x - 1;
      recy = y - 1;
      break;
    case 6:
      recx = x;
      recy = y - 1;
      break;
    case 7:
      recx = x + 1;
      recy = y - 1;
      break;
    }

  /* Figure out what rec should be. First we check if rec is on the map, if 
     not we connect rec to outside. */
    if (recx < 0 || recy < 0 
	|| recx > (mapsizex - 1) || recy > (mapsizey - 1)){
      rec = &outside;
    }
    else {
      rec = (oldmap + ((recx * mapsizey) + recy));
    }

    /* Calculate srctemp and rectemp. */
    srctemp = src->totalcal / src->calperc;
    rectemp = rec->totalcal / rec->calperc;

    /* Is src hotter than rec? */
    if (rectemp >= srctemp) continue;

    /* Now we do the equation to figure out a new temperature. However the
       temperature is saved in an array for later use. After we find how 
       much energy each adjacent mapunit wants then we use another algoritm
       to distribute the energy.
    */

    /* Select cocon from the lesser of the two cocons. */
    if (src->cocon <= rec->cocon){
      cocon = src->cocon;
    }
    else{
      cocon = rec->cocon;
    }

    temp = ((cocon * updateinterval) * ((srctemp - rectemp) / 2));

    /* Add to the amount of calories that could go to this block to wantedcal.
       Also that number is stored in an array. */
    wantedcal += temp;
    reqcal[t] = temp;
    reqpos[t].x = recx;
    reqpos[t].y = recy;
  }

  /* Now that we've figured all that out go and give each block the amount
     of calories it deserves. */
  for (i = 0;i <= 7;i++)
    {
      if (reqcal[i] == 0) continue;

      temp = reqcal[i] * (reqcal[i] / wantedcal);

      /* Set rec and src to null for the addheat function. */
      rec = NULL;
      src = NULL;

      /* Check if reqpos is within the map. */
      if (reqpos[i].x >= 0 && reqpos[i].y >= 0 
	  && reqpos[i].x < mapsizex && reqpos[i].y < mapsizey){
	rec = (curmap + ((reqpos[i].x * mapsizey) + reqpos[i].y));
	rec->totalcal += temp;
      }

      /* Check if src is within the map. */
      if (x >= 0 && y >= 0 && x < mapsizex && y < mapsizey){
	  src = (curmap + ((x * mapsizey) + y)); 
	  src->totalcal -= temp;
      }

      /* Update the score. */
      addheat(rec,src,temp);

    }
}
