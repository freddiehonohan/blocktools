void dotemp();
void calcnewtemp(long x, long y, long recx, long recy);
void distribcal(long x,long y);
