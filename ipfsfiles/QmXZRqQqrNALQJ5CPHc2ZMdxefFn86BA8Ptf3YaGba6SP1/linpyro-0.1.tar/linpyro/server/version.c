/* Version info. */
const char version[] = "LinPyro Server 0.1";
const float fversion = 0.1; /* Floating point version of version. */
const float fileversion = 0.2; /* File version. */
const float netpro = 0.1;      /* Network protocol version. */
