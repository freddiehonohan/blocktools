int loadmap(char *filename);

/* The unittype typedef. In the map files this is the format used for the
   <type> section. See mapformat.txt for more info.
   */
typedef struct unittype {
  char *name;
  int num;
  int temp;
  long double cocon;
  long double calperc;
  long ignitionpoint;
  long double calperf;
  long double fuellevel;
  long double burnspeed;
  int block;
} UNITTYPE;

/* The map name. */
extern char *mapname;
