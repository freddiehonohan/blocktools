#include "main.h"
#include "phys.h"
#include "temp.h"
#include "fire.h"

MAPUNIT *curmap;
MAPUNIT *oldmap;
MAPUNIT outside;

long mapsizex;
long mapsizey;

/*pthread_mutex_t curmap_lock = PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP;
pthread_mutex_t oldmap_lock = PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP;
*/

pthread_mutex_t curmap_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t oldmap_lock = PTHREAD_MUTEX_INITIALIZER;

/* main physics loop */
/* This runs everything physics related, right now thats only dotemp :) */
void dophys()
{

  MAPUNIT *temp;

  pthread_mutex_lock(&curmap_lock);

  /* Run everything needed for the physics simulations. */
  dotemp();
  dofire();


  pthread_mutex_lock(&oldmap_lock);

  /* switch oldmap and curmap */
  temp = oldmap;
  oldmap = curmap;
  curmap = temp;

  pthread_mutex_unlock(&oldmap_lock);
  pthread_mutex_unlock(&curmap_lock);
}

/* Setup all physics engine stuff */
void physetup()
{

  long x,y,i,i2;

  printf("Setting up physics engine...\n");
  printf("Allocating space for the world map\n");

  /* allocate memory for the maps */
  curmap = (MAPUNIT *)malloc(sizeof(MAPUNIT) * (((mapsizex - 1) * mapsizey) + mapsizey));
  if (!curmap){
    fprintf(stderr,"Couldn't allocate memory for curmap, exiting.\n");
    cleanexit(EXIT_FAILURE);
  }
  oldmap = (MAPUNIT *)malloc(sizeof(MAPUNIT) * (((mapsizex - 1) * mapsizey) + mapsizey));
  if (!oldmap){
    fprintf(stderr,"Couldn't allocate memory for oldmap, exiting.\n");
    cleanexit(EXIT_FAILURE);
  }


  printf("Setting up the world map...\n");

  /* create a default map */
  for (x = 0;x < mapsizex; x++){
    for (y = 0;y < mapsizey; y++){

      i = ((x * mapsizey) + y);

      (oldmap + i)->totalcal = K2C;
      (oldmap + i)->cocon = 1;
      (oldmap + i)->calperc = 1;

      (oldmap + i)->ignitionpoint = K2C + 25;
      (oldmap + i)->fuellevel = 0;
      (oldmap + i)->calperf = 15000;
      (oldmap + i)->burnspeed = 1;

      for (i2 = 0;i2 <= topslot;i2++)
	{
	  (oldmap + i)->heatsource[i2] = freeslot;
	  (oldmap + i)->sourcequan[i2] = 0;
	}
    } 
  }

  //(oldmap + ((10 * mapsizey) + 10))->totalcal = K2C + 20;
  //(oldmap + ((5 * mapsizey) + 5))->calperf = 300;
  //(oldmap + ((5 * mapsizey) + 5))->heatsource[0] = 1;
  //(oldmap + ((5 * mapsizey) + 5))->sourcequan[0] = K2C * 3;
  (oldmap + ((0 * mapsizey) + 0))->totalcal = K2C + 15000;
  //(oldmap + ((10 * mapsizey) + 0))->totalcal = K2C + 20;
  //(oldmap + ((15 * mapsizey) + 17))->totalcal = K2C + 20;

}



