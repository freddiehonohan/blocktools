#include <float.h>
#include "main.h"
#include "scorefunc.h"

/* Scoring functions */

/* Does everything needed to update the score for a mapunit.

   rec is the mapunit reciving heat.

   src is the heat source. If src is null a copy of rec is made and used 
   instead for src.

   heat2add is the amount of heat to add.
 */
void 
addheat (MAPUNIT * rec, MAPUNIT * src, long double heat2add)
{
  int i = 0, slot = 0;
  int precheatsrcnum[topslot + 1];
  long double totalheat = 0;
  float prec[topslot + 1];
  MAPUNIT dummy;

  /* Is src null? */
  if (!src)
    {
      dummy = *rec;
      src = &dummy;
    }

  /* Is rec null? */
  if (!rec)
    {
      dummy = *src;
      rec = &dummy;
    }

  /* Clear the arrays. */
  for (i = 0; i <= topslot; i++)
    {
      prec[i] = 0;
      precheatsrcnum[i] = freeslot;
    }

  /* Figure out the percentage of heat that each heatsource gave. */

  /* First find the total amount of heat. */
  for (i = 0; i <= topslot; i++)
    {
      if (src->heatsource[i] != freeslot)
	{
	  totalheat += src->sourcequan[i];
	}
    }

  /* If totalheat is zero just exit. */
  if (totalheat <= 0)
    return;

  /* Figure out what percentage of the total heat each heatsource gave. */
  for (i = 0; i <= topslot; i++)
    {
      precheatsrcnum[i] = src->heatsource[i];
      if (src->heatsource[i] != freeslot && src->sourcequan[i] > 0)
	prec[i] = src->sourcequan[i] / totalheat;
    }

  /* Now figure out the scores based on the percentages. */
  for (i = 0; i <= topslot; i++)
    {
      if (precheatsrcnum[i] != freeslot)
	{

	  /* Find a free slot. */
	  slot = findfreeslot (rec, precheatsrcnum[i]);
#if DEBUG3
	  printf("slot - %d num - %d\n",slot,precheatsrcnum[i]);
#endif
	  rec->heatsource[slot] = precheatsrcnum[i];
	  rec->sourcequan[slot] += heat2add * prec[i];
	  src->sourcequan[slot] -= heat2add * prec[i];

	}
    }
}

/* Adds heat from a specific player. */
void 
addheatfromplayer (MAPUNIT * rec, long double heat2add, int num)
{
  MAPUNIT dummy;
  int i;

  for (i = 0; i <= topslot; i++)
    {
      dummy.heatsource[i] = freeslot;
      dummy.sourcequan[i] = 0;
    }

#if SCOREDEBUG
  printf ("making dummy mapunit num = %d heat2add = %g\n", num, (float) heat2add);
#endif

  /* Makes a dummy mapunit with the specified player in the first slot. */
  dummy.heatsource[0] = num;
  dummy.sourcequan[0] = heat2add;

#if SCOREDEBUG
  printf ("calling addheat %f\n", (float) heat2add);
#endif

  /* Calls addheat. */
  addheat (rec, &dummy, heat2add);

}

/* Finds a free slot or if one doesn't exist uses an existing slot. */

  /* unit is the mapunit to look in and heatsourcenum is the heatsourcenum
     that we are trying to find a slot for. */
int 
findfreeslot (MAPUNIT * unit, int heatsourcenum)
{

  int slotnum, i, topheatslotnum;
  long double topheat = LDBL_MAX;	/* Maximum possible long double. */

  /* First find a free slot. */
  for (slotnum = 0; slotnum <= (topslot + 1); slotnum++)
    {

      /* Have we reached the last slot? */
      if (slotnum > topslot)
	{

	  /* Find the slot with the least amount of heat in it. */
	  for (i = 0; i <= topslot; i++)
	    {
	      if (unit->sourcequan[i] < topheat)
		{
		  topheat = unit->sourcequan[i];
		  topheatslotnum = i;
		}
	    }

	  /* Return with the chosen slot. */
	  return topheatslotnum;

	}

      /* Can we use the slot? */
      if ((unit->heatsource[slotnum] == freeslot) ||
	  (unit->heatsource[slotnum] == heatsourcenum))
	{
	  /* Return with the slotnum. */
	  return slotnum;
	}
    }

  return 0;
}
