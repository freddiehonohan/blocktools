#include <math.h>
#include <sys/time.h>
#include <sys/signal.h>
#include "main.h"
#include "loop.h"
#include "display.h"
#include "phys.h"
#include "net.h"

int stop = 0;
double updateinterval;

pthread_t *netthread;

int handler(int sig); /* Signal handler */

/* Main loop code */

/* This code makes sure all stuff (physics, network, input) is done and makes
   sure it isn't done too often */
void mainloop()
{

  struct timespec sleeptime;
  int r;

  /* Start the loop. */
  do {

    /* Do everything we need to do. */
    dophys();

    /*displaymap();*/

    /* This code then waits untill we should update again. */

    /* First convert updateinterval to the format we want to use. */
    sleeptime.tv_sec = (time_t)(floor(updateinterval));
    sleeptime.tv_nsec = (updateinterval - sleeptime.tv_sec) * 1000000000;

    /* Sleep for updateinterval nanoseconds */
    r = nanosleep(&sleeptime,NULL);

  } while (!stop);

} 

/* Network loop. */
void *netloop(void *junk){
  struct timespec sleeptime;

  do {

    sleeptime.tv_sec = 0;
    sleeptime.tv_nsec = 100000000;

    /* r = nanosleep(&sleeptime,NULL);*/

    check4new(NULL);

  } while(1);

  return NULL;
}

/* Sets up the signals. */
void setupsignals(){
  /* Setup the SIGINT handling */
  //signal(SIGINT,handler);
}

int handler(int sig){

  if (sig == SIGINT){
    cleanexit(EXIT_FAILURE);
  }

  return 0;
}

/* Does a clean exit. */
void cleanexit(int exittype){

  /* Kill the network thread. */
  pthread_cancel(*netthread);

  /* Exit. */
  exit(exittype);

  return;

}


