#include "main.h"
#include "../shared/netpro.h"
#include "player.h"

pthread_mutex_t playerlist_lock = PTHREAD_MUTEX_INITIALIZER;
PLAYERINFO *playerlist = NULL;
int numplayers = 0;

MAP_VERTEX *s_points = NULL;
int s_pointsnum = 0;

int s_pointindex = 0;
pthread_mutex_t s_pointindex_lock = PTHREAD_MUTEX_INITIALIZER;

/* Adds a player to the list. */
int addplayer(char *name){
  MAP_VERTEX spos;

  pthread_mutex_lock(&playerlist_lock);

  numplayers++;

  /* realloc space. */
  playerlist = realloc(playerlist,numplayers * sizeof(PLAYERINFO));

  /* Add the player. */
  playerlist[numplayers - 1].num = numplayers - 1;
  playerlist[numplayers - 1].score = 0;

  /* Get a starting point. */
  getstartpos(&spos);
  playerlist[numplayers - 1].x = spos.x;
  playerlist[numplayers - 1].y = spos.y;
  playerlist[numplayers - 1].team = 0;
  playerlist[numplayers - 1].health = 100;
  strcpy(playerlist[numplayers - 1].name,name);

#if DEBUGPLAYERS
  int i;
  for (i = 0; i < numplayers; i++){
    if (playerlist[i].num != -1)
      printf("Player %d - %s\n",i,playerlist[i].name);
  }
#endif

  pthread_mutex_unlock(&playerlist_lock);

  return playerlist[numplayers - 1].num;
}

/* Deletes player num. */
void delplayer(int pnum){

  playerlist[pnum].num = -1;

#if DEBUGPLAYERS
  int i;
  for (i = 0; i < numplayers; i++){
    if (playerlist[i].num != -1)
      printf("Player %d - %s\n",i,playerlist[i].name);
  }
#endif

}

/* Changes a players info. Also bounds the new values. */
void chgplayerinfo(int pnum,PLAYERINFO newinfo){

  /* First step. Check that pnum is valid. */
  if (pnum < 0)
    return;

  if (pnum >= numplayers)
    return;

  if (playerlist[pnum].num < 0)
    return;

  /* Second step. Bound newinfo. */

  /* Third step. Copy over newinfo. */

  if (playerlist[pnum].health > 0){
    playerlist[pnum].x = newinfo.x;
    playerlist[pnum].y = newinfo.y;
  }

}

/* Finds a starting position. The positions are used one at a time in sequence.
   Thats why this function's has a external index variable and a lock that it
   uses.
*/
void getstartpos(MAP_VERTEX *pos){

  pthread_mutex_lock(&s_pointindex_lock);

  *pos = s_points[s_pointindex];

  s_pointindex++;

  if (s_pointindex == s_pointsnum)
    s_pointindex = 0;

  pthread_mutex_unlock(&s_pointindex_lock);
}
