void addheat(MAPUNIT *rec, MAPUNIT *src, long double heat2add);
void addheatfromplayer(MAPUNIT *rec,long double heat2add,int num);
int findfreeslot(MAPUNIT *unit,int heatsourcenum);
