#include <math.h>
#include "main.h"
#include "phys.h"
#include "fire.h"
#include "scorefunc.h"

/* This does one cycle of the fire simulation. */

/* The algorithm used is very simple. If the temperature is above the ignition
   temperature burn burnspeed fuel and add calperf * burnspeed calories to the
   mapunit. Nothing else is done. */
void dofire()
{

  long x, y;
  int temp;
  long double fuel2burn,heat2add;
  MAPUNIT *cur; /* The mapunit we are changing */

  for (x = 0;x < mapsizex;x++){
    for (y = 0;y < mapsizey;y++){

      cur = (curmap + ((x * mapsizey) + y));
      temp = cur->totalcal / cur->calperc;

      /* Is the mapunit above ignition temperature and is there any fuel
	 left to burn? */
      if (temp >= cur->ignitionpoint && cur->fuellevel > 0){

	fuel2burn = (cur->burnspeed * updateinterval);

	if (fuel2burn > cur->fuellevel) fuel2burn = cur->fuellevel;

	cur->fuellevel -= fuel2burn;

	heat2add = fuel2burn * cur->calperf;
	cur->totalcal += heat2add;

	/* Update the score. src is NULL since there is no source. */
	addheat(cur,NULL,heat2add);

      }
    }
  }
}

