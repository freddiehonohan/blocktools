/* typedefs for the physics model */

/* This typedef is used for every unit of space that is simulated. 

Please note that when I say calorie I don't mean something that is equal in
quantity to the scientific meaning. Every unit is treated as though it is a
1cm3 cube. However in the game each unit could be as much as 1m3.

The varibles included are:

Temp stuff:

totalcal The total energy content of the block in calories.

cocon    Coefficent of conductivity - cal/unit-sec-C

calperc  Calories needed for each 1 C of temperature for the unit.

Fire stuff:

ignitionpoint How hot (in kevins) the material has to be to catch on fire.

fuellevel     Current fuel level.

calperf       Calories released per 1 fuel.

burnspeed     Fuel burn't per second.

Scoring stuff:

heatsource[]  What heat source's provided heat for the mapunit.
sourcequan[]  Each heatsource has a number. Whenever heat is transfered from
	      one mapunit to another a entry is put in heatsource with the
	      heatsource number and how much energy was transfered is put in
	      sourcequan[] If heatsource is 0 that means that the slot is
	      empty.

*/

typedef struct mapunit {

  /* Temperature related stuff */
  long double totalcal;
  long double cocon;
  long double calperc;

  /* Fire related stuff */
  int ignitionpoint;
  long double fuellevel;
  long double calperf;
  long double burnspeed;

  /* Score related stuff */
  int heatsource[15];
  long double sourcequan[15];

  int block; /* Can the player pass through the map unit? */

} MAPUNIT;

/* How much you need to subtract to get celsius from kelvin */
#define K2C 273

/* Highest possible slot number for heatsource. */
#define topslot 14

#define freeslot 0
