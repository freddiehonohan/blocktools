/* typedefs for the network protocol. */

/* The overhead of the net protocol. This includes the checksum and some 
   other stuff. */
typedef struct netoverhead {

  /* x and y coords of the map unit. */
  long x;
  long y;

  char checksum;

  /* Type of packet. See below #defines for details. */
  int type;

} NETOVERHEAD;

typedef struct firstmap {

  /* Temperature related stuff */
  long double totalcal;
  long double cocon;
  long double calperc;

  /* Fire related stuff */
  int ignitionpoint;
  long double fuellevel;
  long double calperf;
  long double burnspeed;

  int block; /* Can the player pass through the map unit? */

  NETOVERHEAD neto; /* Network protocol overhead. */

} FIRSTMAP;

typedef struct updatemap {

  /* Temperature related stuff */
  long double totalcal;

  /* Fire related stuff */
  long double fuellevel;

  NETOVERHEAD neto; /* Network protocol overhead. */

} UPDATEMAP;

typedef struct playerinfo {

  char name[30]; /* Players name. */
  long score;    /* Players score. */
  int team;      /* Team. Not used, yet. */

  int health;    /* Current health. Starts at 100. If 0 the player is dead. */

  long x;        /* x pos. */
  long y;        /* y pos. */
		    
  int num;       /* Identification number. -1 if entry is unused. */

  NETOVERHEAD neto; /* Network protocol overhead. */

} PLAYERINFO;

/* Packet types. */
#define TYPE_DATA  1 /* Data. */
#define TYPE_DONE  2 /* Done */
#define TYPE_READY 3 /* Ready to recive, currently used for login. */
#define TYPE_ERR   4 /* Error. */
