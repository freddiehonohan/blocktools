/* Checksum function. */

/* The algoritm used isn't the normal checksum. All I do is exclusive or each
   byte untill I'm done. Then I return with the result. It's really simple.
   Really fast. And works well enough.
   */

/* buff is the buffer to checksum. len is the size of the buffer. Simple? I
   think so. */
char checksum(void *buff,int len)
{
  int i;
  char checksum = 0;
  char *buff2;

  buff2 = (char *)buff;

  for (i = 0; i < len; i++){
    checksum ^= buff2[i];
  }

  return checksum;
}
