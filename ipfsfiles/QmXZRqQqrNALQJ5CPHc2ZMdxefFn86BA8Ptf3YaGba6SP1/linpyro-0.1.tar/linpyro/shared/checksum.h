char checksum(void *buff,int len);
