void mvplayer(int x, int y);

extern int playerx;
extern int playery;

extern PLAYERINFO *playerlist;
extern int numplayers;

extern int ournum;

/* Note that these defines need the curses.h include file to work. Otherwise
   you'll get compile errors. */
#if PC_CHAR
#define PLAYER_CHAR_ME (A_ALTCHARSET | 2)
#define PLAYER_CHAR_OTHER (A_ALTCHARSET | 1)
#define PLAYER_CHAR_ME_DEAD '*'
#define PLAYER_CHAR_OTHER_DEAD 'o'
#else
#define PLAYER_CHAR_ME '*'
#define PLAYER_CHAR_OTHER 'o'
#define PLAYER_CHAR_ME_DEAD '*'
#define PLAYER_CHAR_OTHER_DEAD 'o'
#endif

