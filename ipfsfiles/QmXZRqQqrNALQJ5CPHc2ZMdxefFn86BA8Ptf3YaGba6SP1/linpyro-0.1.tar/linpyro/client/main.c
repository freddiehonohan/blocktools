/* LinPyro Client 0.1 */
#include "main.h"
#include "net.h"
#include "loop.h"
#include "version.h"
#include "display.h"

/* Status vars. */
int scrsetup = 0;        /* Has the screen been setup? */
int have_playerlist = 0; /* Do we have a playerlist? */
int net = 0;             /* Are we connected to a server? */
int login_done = 0;      /* Have we logged in seccessfully? */
int setfire = 0;

int main(int argc,char *argv[])
{
  mapsizex = 76;
  mapsizey = 20;

  /* Did the user give us any arguments? */
  if (argc <= 1){
        fprintf(stderr,
		"Please specifify a server and optionally a port number.\n");
	exit(EXIT_FAILURE);
  }

  /* Connect to server specifified on port 3140, the standard port or
   if specififed another port. Code removed for now
  if (argc > 2) 
    conportnum = atoi(argv[argc - 1]);*/

  /* Instead the other argument is the playername. */
  if (argc > 2){
    playername = malloc(strlen(argv[argc - 1]));
    playername = strcpy(playername,argv[argc - 1]);
  }

  conserver = malloc(strlen(argv[1]));
  conserver = strcpy(conserver,argv[1]);

  /* Setup the screen */
  setupscr();

  /* Setup the signals */
  setupsignals();

  /* Start mainloop */
  mainloop();

  return 0;
}
