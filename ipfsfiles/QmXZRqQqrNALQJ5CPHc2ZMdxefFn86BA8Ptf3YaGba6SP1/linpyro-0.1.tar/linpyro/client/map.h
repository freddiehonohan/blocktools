#include "../shared/phydefs.h"

extern long mapsizex;
extern long mapsizey;
extern char *mapname;
extern int havemap;
extern MAPUNIT *map;
