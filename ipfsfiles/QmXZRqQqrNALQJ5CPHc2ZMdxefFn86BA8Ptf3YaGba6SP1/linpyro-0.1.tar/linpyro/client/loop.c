/* Loop functions. Also contains the signal functions. */
#include "main.h"
#include "loop.h"
#include "display.h"
#include "net.h"

#include <sys/time.h>
#include <sys/signal.h>

void cleanexit(int exittype);

int signalhandler(int sig); /* Signal handler */

float updateinterval; /* The update interval in seconds. Note that this should
			 equal the update interval of the server. Otherwise 
			 bad things happen. */

int syncing;

/* Main loop. */

/* update interval is the update interval in seconds. Each time "the world" is
   updated everything is sent/recived from the server and the display is 
   updated.
   */
void mainloop()
{

  while (1){
    drawscreen();
    check4key();

    /* Do we need to get onto the server? */
    if (!net && conportnum)
      connect2server(conserver,conportnum);
    
    //if (updatedisplay)
      drawscreen();
  }

}

/* Sets up all of the signals. */
void setupsignals()
{
  int signalhandler(int sig); /* Signal handler */
   
  setuptimer();

  /* Setup the SIGINT handling */
  signal(SIGINT,signalhandler);
}

/* Sets up the timer for the syncnet function. Every 0.1 (by default) seconds
   the syncnet function will be called. */
void setuptimer()
{
  int r;

  int signalhandler(int sig); /* Signal handler */
  
  struct itimerval timer;

  timer.it_value.tv_sec = 0;
  timer.it_value.tv_usec = 1000000;
  timer.it_interval.tv_sec = 0;
  timer.it_interval.tv_usec = 1000000;

  /* Setup the signal handler */
  signal(SIGALRM,signalhandler);

  /* Setup the alarm */
  r = setitimer(ITIMER_REAL,&timer,NULL);

  if (r != 0) perror("setitimer");
}

/* Signal handler */
int signalhandler(int sig)
{

  if (sig == SIGALRM){
    setuptimer(); /* Reset the timer */
    if (syncing == 0){
      syncing = 1;
      syncnet(0);
      syncing = 0;
    }
  }
  else if (sig == SIGINT){
    /* Call the cleanexit function which will perform a nice clean exit
     for us.*/
    cleanexit(EXIT_FAILURE);
  }

  return 0;
}

/* Cleanly exits the program */
void cleanexit(int exittype)
{

  /* Reset the screen. */
  if (scrsetup) 
    resetscreen();
 
  /* Disconnect from the server. */
  if (net)
    resetnet();

  exit(exittype);
}
