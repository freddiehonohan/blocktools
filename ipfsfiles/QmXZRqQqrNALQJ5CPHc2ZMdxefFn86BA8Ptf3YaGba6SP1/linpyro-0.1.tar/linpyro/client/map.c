#include "main.h"
#include "map.h"

/* Stuff discribing the map. */
long mapsizex,mapsizey;
char *mapname = NULL;

/* The map we have gotten from the server. */
MAPUNIT *map;

/* true if we actually have a map. */
int havemap = 0;
