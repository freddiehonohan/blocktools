#include "net.h"
#include "main.h"
#include "player.h"
#include "map.h"

int playerx;
int playery;

/* Player info. */
PLAYERINFO *playerlist = NULL;
int numplayers = 0;
int ournum = -1; /* Our playernum. */
 
#define MAXMOVE 1

/* Moves the player to x, y If the player can't move there this function
   doesn't move the player. Very simple. ;)
*/
void mvplayer(int x, int y)
{

  /* If we don't have the playerlist just exit. */
  if (!have_playerlist)
    return;

  /* If we are dead just exit. */
  if (playerlist[ournum].health <= 0)
    return;

  /* If the playerinfo hasn't been updated yet just exit. */
  if (updatedplayerinfo > 1)
    return;

  /* Since the info has been updated mark it as not updated. */
  updatedplayerinfo++;

  /* First check if we are moving more then MAXMOVE unit in each direction. */
  if (x - playerx > MAXMOVE) 
    x = playerx + MAXMOVE;

  else if (playerx - x > MAXMOVE)
    x = playerx - MAXMOVE;
 
  if (y - playery > MAXMOVE) 
    y = playery + MAXMOVE;
 
  else if (playery - y > MAXMOVE)
    y = playery - MAXMOVE;

  /* Check if x or y are outside of the map. */
  if (x < 0) 
    x = 0;
  else if (x > (mapsizex - 1))
    x = (mapsizex - 1);
 
  if (y < 0) 
    y = 0;
  else if (y > (mapsizey - 1))
    y = (mapsizey - 1);

  /* Check if the dest is blocked. */
  if (map[x * mapsizey + y].block){
    x = playerx;
    y = playery;
  }

  /* Still here? Better set x and y than. */
  playerx = x;
  playery = y;

  /* Also patch playerinfo. */
  playerlist[ournum].x = playerx;
  playerlist[ournum].y = playery;
}
