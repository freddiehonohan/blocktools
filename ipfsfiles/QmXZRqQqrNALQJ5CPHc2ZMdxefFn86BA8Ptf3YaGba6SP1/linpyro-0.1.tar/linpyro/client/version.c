/* Version info. */

const char version[] = "LinPyro Client 0.1";
const float fversion = 0.1; /* Floating point version of version. */
const float netpro = 0.1;      /* Network protocol version. */
