/* Display functions */
#include "main.h"
#include "net.h"

#include <curses.h> /* The curses library. */
#include <panel.h>  /* The panel library, needed for the windows. */

#include "display.h"
#include "player.h"
#include "map.h"

void showhelp(); /* Private functions. */
void hidehelp();
chtype findch(long x, long y);
short findcolor(long x, long y);

/* Windows that are used. The panels for to these windows are below. */
WINDOW *winstatus;    /* The status bar. */
WINDOW *winmap;       /* The map screen. */
WINDOW *winmapmsgdiv; /* The devider between the map and msg box. */
WINDOW *winmsg;       /* The message screen. */
WINDOW *winhelp;      /* The help screen. */

PANEL *panstatus;
PANEL *panmap;
PANEL *panmapmsgdiv;
PANEL *panmsg;
PANEL *panhelp;

int MSGSIZE = 4;

/* Should the display be updated? */
int updatedisplay = UP_ALL;

/* What window is currently selected. Which window was last selected. */
int selwin,lastsel;
#define SEL_MAP  1
#define SEL_MSG  2
#define SEL_HELP 3

/* Messages that go in the msg box. */
char **messages = NULL;
int nummsgs = 0;
int firstmsg = 0; /* The start of the messages that we draw. */

/* The keys and the keys mapped to them. */
int MK_UP = KEY_UP;
int MK_DOWN = KEY_DOWN;
int MK_LEFT = KEY_LEFT;
int MK_RIGHT = KEY_RIGHT;

int MK_HELP = KEY_F(1);
int MK_HELPQUIT = 'q';

int MK_SETFIRE = ' ';

/* The status bar's color. */
#define STATUS_FG    COLOR_BLACK
#define STATUS_BG    COLOR_WHITE
#define STATUS_COLOR 1

/* The forground color. */
#define DFG COLOR_WHITE

/* The different background colors. */
#define BCOLOR_BLACK 2
#define BCOLOR_RED 3
#define BCOLOR_GREEN 4
#define BCOLOR_YELLOW 5
#define BCOLOR_BLUE 6
#define BCOLOR_MAGENTA 7
#define BCOLOR_CYAN 8
#define BCOLOR_WHITE 9
 
/* The different shades of color. */
#define RED1 (COLOR_PAIR(BCOLOR_RED))
#define RED2 (COLOR_PAIR(BCOLOR_RED) | A_BOLD

#define GREEN1 (COLOR_PAIR(BCOLOR_GREEN))
#define GREEN2 (COLOR_PAIR(BCOLOR_GREEN) | A_BOLD)

#define YELLOW1 (COLOR_PAIR(BCOLOR_YELLOW))
#define YELLOW2 (COLOR_PAIR(BCOLOR_YELLOW) | A_BOLD)

#define BLUE1 (COLOR_PAIR(BCOLOR_BLUE))
#define BLUE2 (COLOR_PAIR(BCOLOR_BLUE) | A_BOLD)

#define MAGENTA1 (COLOR_PAIR(BCOLOR_MAGENTA))
#define CYAN1 (COLOR_PAIR(BCOLOR_CYAN))

/* The help windows size and pos. */
#define HELP_COLS (COLS - 10)
#define HELP_LINES (LINES - 7)
#define HELP_X ((COLS - HELP_COLS) / 2)
#define HELP_Y ((LINES - HELP_LINES) / 2)

/* Setup the screen */
void setupscr()
{
  playerx = 1;
  playery = 1;

  /* Flag the fact that the screen has been setup. */
  scrsetup = 1;

  /* Init the screen. */
  initscr();

  cbreak();
  noecho();
  nonl();

  immedok(stdscr,TRUE);

  halfdelay(1);
  intrflush(stdscr, FALSE);
  keypad(stdscr, TRUE);

  typeahead(-1);

  /* Make the cursor invisible. */
  /* curs_set(0); Disabled while debugging. */

  start_color();

  /* Setup the status bar color. */
  init_pair(STATUS_COLOR,STATUS_FG,STATUS_BG);

  /* Setup the other colors. */
  init_pair(BCOLOR_BLACK,DFG,COLOR_BLACK);
  init_pair(BCOLOR_RED,DFG,COLOR_RED);
  init_pair(BCOLOR_GREEN,DFG,COLOR_GREEN);
  init_pair(BCOLOR_YELLOW,DFG,COLOR_YELLOW);
  init_pair(BCOLOR_BLUE,DFG,COLOR_BLUE);
  init_pair(BCOLOR_WHITE,DFG,COLOR_WHITE);
  init_pair(BCOLOR_MAGENTA,DFG,COLOR_MAGENTA);
  init_pair(BCOLOR_CYAN,DFG,COLOR_CYAN);

  /* Setup the windows and their corrasponding panels. */
  winstatus = newwin(1,COLS,0,0);
  winmap = newwin(LINES - MSGSIZE - 1,COLS,1,0);
  winmapmsgdiv = newwin(1,COLS,LINES - MSGSIZE - 1,0);
  winmsg = newwin(MSGSIZE,COLS,LINES - MSGSIZE,0);
  winhelp = newwin(HELP_LINES,HELP_COLS,HELP_Y,HELP_X);

  panstatus = new_panel(winstatus);
  panmap = new_panel(winmap);
  panmapmsgdiv = new_panel(winmapmsgdiv);
  panmsg = new_panel(winmsg);
  panhelp = new_panel(winhelp);

  /* Change the status bar color. */
  wattrset(winstatus,COLOR_PAIR(STATUS_COLOR));

  /* Allow the msgbox to scroll. */
  scrollok(winmsg,TRUE);

  top_panel(panstatus);
  top_panel(panmap);
  top_panel(panmapmsgdiv);
  top_panel(panmsg);
  hide_panel(panhelp);

  /* Select the map for the selected window. */
  selwin = SEL_MAP;

  /* Draw the screen. */
  drawscreen();
}

/* Resets the screen */
void resetscreen()
{
  endwin();
}

/* Draws the screen. This just quickly draws the screen with whatever should
   be in the different windows. 
*/     
void drawscreen()
{
  long x,y;
  int i;
  long temp = 0;
  int health = 0;
  int score;

  /* Should the status bar be updated? */
  if ((updatedisplay & UP_STATUS) != 0){
    /* Clear the status bar. */
    werase(winstatus);

    if (havemap)
      temp = (long)map[playerx * mapsizey + playery].totalcal - K2C;

    if (havemap && have_playerlist){
      health = playerlist[ournum].health;
      score = (int)playerlist[ournum].score;
    }

    wprintw(winstatus,"mapsize - %ld, %ld temp - %ld health - %d score - %d",
	    mapsizex,mapsizey,temp,health,score);

  }
 
  /* Should the map be updated? */
  if ((updatedisplay & UP_MAP) != 0 && havemap){

    /* Clear the inside of the map window. */
    werase(winmap);

    /* Draw the map. */
    for (y = 0; y < mapsizey;y++){
      for (x = 0;x < mapsizex;x++){
	waddch(winmap,findch(x,y));
      }
      waddch(winmap,'\n');
    }

    for (y = 0; y < mapsizey;y++){
      for (x = 0;x < mapsizex;x++){
	/* Change the color to the right color. */
	mvwchgat(winmap,y,x,1,0,findcolor(x,y),NULL);
      }
    }

    if (have_playerlist){
      /* Draw the players in the map. */
      for (i = 0; i < numplayers; i++){

	if (playerlist[i].num > -1){

	  if (i == ournum && playerlist[i].health > 0)
	    mvwaddch(winmap,playerlist[i].y,playerlist[i].x,PLAYER_CHAR_ME);
	  else if (i != ournum && playerlist[i].health > 0)
	    mvwaddch(winmap,playerlist[i].y,playerlist[i].x,PLAYER_CHAR_OTHER);
	  else if (i == ournum && playerlist[i].health <= 0)
	    mvwaddch(winmap,playerlist[i].y,playerlist[i].x,PLAYER_CHAR_ME_DEAD);
	  else if (i != ournum && playerlist[i].health <= 0)
	    mvwaddch(winmap,playerlist[i].y,playerlist[i].x,PLAYER_CHAR_OTHER_DEAD);

	  /* Change the color back to the right color. - Currently removed 
	     because doing this gets rid of our happy faces. :(
	     mvwchgat(winmap,playerlist[i].y,playerlist[i].x,1,0,
	     findcolor(playerlist[i].x,playerlist[i].y),NULL);
	  */
	}
      }
    

      /* Draw ourself. This makes sure that we can always see ourself on the 
	 map. Otherwise another player might be drawn ontop of us. */
      i = ournum;

      if (i == ournum && playerlist[i].health > 0)
	mvwaddch(winmap,playerlist[i].y,playerlist[i].x,PLAYER_CHAR_ME);
      else if (i != ournum && playerlist[i].health > 0)
	mvwaddch(winmap,playerlist[i].y,playerlist[i].x,PLAYER_CHAR_OTHER);
      else if (i == ournum && playerlist[i].health <= 0)
	mvwaddch(winmap,playerlist[i].y,playerlist[i].x,PLAYER_CHAR_ME_DEAD);
      else if (i != ournum && playerlist[i].health <= 0)
	mvwaddch(winmap,playerlist[i].y,playerlist[i].x,PLAYER_CHAR_OTHER_DEAD);

      /* Change the color back to the right color. - Currently removed 
	 because doing this gets rid of our happy faces. :(
	 mvwchgat(winmap,playerlist[i].y,playerlist[i].x,1,0,
	 findcolor(playerlist[i].x,playerlist[i].y),NULL);*/
    }
  }

  /* Should we update the msgbox? */
  if ((updatedisplay & UP_MSG) != 0){
  
    /* Draw the line seperating the msg box and the map. */
    for (x = 0; x < COLS; x++){
      mvwaddch(winmapmsgdiv,0,x,ACS_HLINE);
    }

    /* Clear the inside of the msg box. */
    werase(winmsg);

    /* Draw the messages in the msg box. */
    for (x = 0; x < nummsgs; x++){
      wprintw(winmsg,"%s\n",messages[x]);
    }
  }

  /* Refresh the panels */
  update_panels();

  /* Refresh the screen. */
  refresh();

  updatedisplay = 0;
}

/* Get a character and do whatever we need to based on what character we
   got. */
void check4key()
{
  int ch;

  ch = getch();

  /* Was there a character waiting? */
  if (ch == ERR) 
    return;

  /* Figure out what to do with the character. */

  /* All of the windows support the F1 key. */
  if (ch == MK_HELP){
    showhelp(); /* There is no need to update the display after showhelp. */
    lastsel = selwin;
    selwin = SEL_HELP;
    updatedisplay = UP_ALL;
    return;
  }

  /* Is the map selected? And do we have a map? */
  if (selwin == SEL_MAP && net){
    if (ch == MK_UP) mvplayer(playerx,playery - 1);
    if (ch == MK_DOWN) mvplayer(playerx,playery + 1);
    if (ch == MK_LEFT) mvplayer(playerx - 1,playery);
    if (ch == MK_RIGHT) mvplayer(playerx + 1,playery);
    if (ch == MK_SETFIRE) setfire = 1;
    updatedisplay |= UP_MAP; /* Any map operations need a display update. */
    return;
  }

  /* Is the msgbox selected? */
  if (selwin == SEL_MSG){
    return;
  }

  /* Is the help window selected? */
  if (selwin == SEL_HELP){
    if (ch == MK_HELPQUIT){
      hidehelp();
      selwin = lastsel;
      updatedisplay = UP_ALL;
    }
  }

}

/* Shows a help screen. */
void showhelp()
{
  top_panel(panhelp);
}

void hidehelp()
{
  hide_panel(panhelp);
}

/* Finds what character should be displayed for the specified part of the map
   based on the block attr and the blocks around the mapunit.
 */
chtype findch(long x, long y)
{

  if (!map[x * mapsizey + y].block)
    return ' ';

  return ACS_CKBOARD;
}

short findcolor(long x, long y){
  int temp;
  int fuellevel;
  int fuelcalpers;
  float cocon;

  temp = map[x * mapsizey + y].totalcal / map[x * mapsizey + y].calperc;
  fuellevel = map[x * mapsizey + y].fuellevel;
  fuelcalpers = map[x * mapsizey + y].burnspeed * 
    map[x * mapsizey + y].calperf;
  cocon = map[x * mapsizey + y].cocon;

  if (temp > 100 + K2C && temp < 150 + K2C)
    return BCOLOR_YELLOW;
  else if (temp >= 150 + K2C)
    return BCOLOR_RED;
  else if (fuellevel > 0 && fuelcalpers < 100)
    return BCOLOR_GREEN;
  else if (fuellevel > 0 && fuelcalpers >= 100)
    return BCOLOR_MAGENTA;
  else if (cocon < 0.1)
    return BCOLOR_BLUE;
  else if (cocon > 1)
    return BCOLOR_CYAN;

  return 0;
}
