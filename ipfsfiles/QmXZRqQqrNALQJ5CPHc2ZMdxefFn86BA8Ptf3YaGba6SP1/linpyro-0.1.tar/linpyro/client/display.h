void setupscr(); 
void resetscreen();
void drawscreen();
void check4key();

extern int updatedisplay;

/* AND these together to choose what to update. */
#define UP_STATUS 1
#define UP_MAP    2
#define UP_MSG    4
#define UP_HELP   8

#define UP_ALL (UP_MAP | UP_MSG | UP_HELP | UP_STATUS)
