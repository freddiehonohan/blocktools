extern const char version[];
extern const float fversion;
extern const float fileversion;
extern const float netpro;
