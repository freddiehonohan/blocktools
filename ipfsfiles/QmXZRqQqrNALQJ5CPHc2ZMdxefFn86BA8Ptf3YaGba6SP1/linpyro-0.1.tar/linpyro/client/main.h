#include <stdio.h>
#include <stdlib.h>

extern int scrsetup;
extern int net;
extern int have_playerlist;
extern int login_done;
extern int setfire;
