/* Network functions. */
#include "main.h"
#include "net.h"
#include "../shared/checksum.h"
#include "loop.h"
#include "display.h"
#include "version.h"
#include "player.h"
#include "map.h"

/* Network includes. */
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#include <fcntl.h>

#define BLEN 1024

int updatedplayerinfo = 0;

int recv2tmpbuf();
void totsend(int sock,void *buff,int len,int op);
int totrecv(int sock,void *buff,int len,int op);

int sockfd;

char tmpbuf[BLEN];

float remprotocolversion;

/* The server we are connected to. If portnum is zero we are not connected 
   to a server. 
*/
char *conserver;
int conportnum = 3140;

/* Our name. */
char *playername;

/* If 1 close the connection. */
int closecon = 0;

/* Connects to a server. This function doesn't "log in" but just connects
   to the server at the specified port. Also it will soon translate 
   strings into ip addresses. */
void connect2server(char *server,int portnum)
{
  int r;
  struct hostent *he;
  struct sockaddr_in their_addr; /* connector's address information */

  /* Lookup the address with DNS. */
  he = gethostbyname(server);
  if (he == NULL){
    herror("gethostbyname");
    cleanexit(EXIT_FAILURE);
  }

  /* Create a socket for us to use. */
  if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    perror("socket");
    cleanexit(EXIT_FAILURE);
  }

  /* Setup their_addr. */
  their_addr.sin_family = AF_INET;      /* host byte order */
  their_addr.sin_port = htons(portnum);    /* short, network byte order */
  their_addr.sin_addr = *((struct in_addr *)he->h_addr);
  bzero(&(their_addr.sin_zero), 8);     /* zero the rest of the struct */

  /* Try to connect at the port specified. */
  if (connect(sockfd, (struct sockaddr *)&their_addr, 
	      sizeof(struct sockaddr)) == -1) {
    perror("connect");
    cleanexit(EXIT_FAILURE);
  }

  /* Set our socket to non-blocking. */
  fcntl(sockfd, F_SETFL, O_NONBLOCK);

  /* Get the version of the server protocol. */
  totsend(sockfd,"protocolversion;",16,0);

  r = recv2tmpbuf();
  tmpbuf[r] = '\0';

  remprotocolversion = (float)atof(tmpbuf);

  /* Check if the protocol version is higher then the one we can use. */
  if (netpro < remprotocolversion){
    fprintf(stderr,"Error! Server protocol version is higher then our protocol version!\nServer uses %g I use up to %g\n",(float)atof(tmpbuf),netpro);
    close(sockfd);
    cleanexit(EXIT_FAILURE);
  }

  /*printf("protocolversion = %g\n",remprotocolversion);*/

  /* Get info on the map. */
  totsend(sockfd,"getmapinfo;",11,0);

  r = recv2tmpbuf();
  tmpbuf[r] = '\0';

  /* Parse the stuff we got back. */
  r = sscanf(tmpbuf,"%ld %ld \"%s\"",&mapsizex,&mapsizey,mapname);

  /* If we got a valid mapsizex and mapsizey get the map from the server. */
  if (mapsizex > 0 && mapsizey > 0){

    /* Malloc space for the map. */
    map = malloc(sizeof(MAPUNIT) * (((mapsizex - 1) * mapsizey) + mapsizey));

    /* Gets the map. */
    getfirstmap();
  }

  /* Make sure the map gets updated. Also flag the fact that we have a map. */
  updatedisplay |= UP_ALL;
  havemap = 1;

  /* Flag the fact that we are connected to a server. */
  net = 1;

  /* Login as playername. */
  r = login2server(playername);

  if (r == 0)
    login_done = 1;
}

/* Gets important info from the server like the update interval. 
 Currently not very well developed. :) */
void getinfo()
{
  updateinterval = 0.1;
}

/* Syncs our world view and the servers world and sends anything else that we
   need to like player movement messages. If force is set this function will
   ignore a zero net varible.
   */
void syncnet(int force)
{

  /* Are we connected to a server? */
  if (!net && !force)
    return;

  totsend(sockfd,";",1,0);

  updatemap();

  totsend(sockfd,";",1,0);

  /* Send playerinfo info before we update the map so we can get updated values
     from the server faster.
     */
  sendplayerinfo();

  /* Should we set a fire? */
  if (setfire == 1){
    setfire = 0;
    totsend(sockfd,";",1,0);
    totsend(sockfd,"setfire;",8,0);
  }

  totsend(sockfd,";",1,0);

  updateplayerinfo();

  updatedisplay |= UP_MAP | UP_STATUS;

  /* Say we updated the playerinfo. */
  if (updatedplayerinfo > 0 )
    updatedplayerinfo--;
}

/* Resets the net connection. Right now the server seems to be having trouble
 actually recognizing the close command. :( */
void resetnet()
{
  totsend(sockfd,";",6,0);
  totsend(sockfd,"close;",6,0);
}

/* Gets the map to start off with. */
void getfirstmap()
{
  int r;
  long x,y;
  FIRSTMAP tmpfirstmap;
  char checksum2; /* The name checksum is already taken. */
  
  totsend(sockfd,"getallmap;",10,0);

  while (1){
    /* recv the struct and put it where it belongs. */
    r = totrecv(sockfd,&tmpfirstmap,sizeof(FIRSTMAP),0);

    /* Check if this is the last packet. */
    if (tmpfirstmap.neto.type != TYPE_DATA)
      break;

    /* Now check the checksum. We do this after checking for TYPE_DONE because
       the TYPE_DONE packet doesn't have a checksum. */
    checksum2 = tmpfirstmap.neto.checksum;
    tmpfirstmap.neto.checksum = 0;
    tmpfirstmap.neto.checksum =
      checksum(&tmpfirstmap,sizeof(FIRSTMAP));

    
    if (checksum2 != tmpfirstmap.neto.checksum){
      printf("Error! Checksums don't match. Got %d Calculated %d\n",
	     (int)checksum2, (int)tmpfirstmap.neto.checksum);
      cleanexit(EXIT_FAILURE);
    }

    x = tmpfirstmap.neto.x;
    y = tmpfirstmap.neto.y;
    
    /* Copy the stuff in tmpfirstmap to the correct locations. */
    map[x * mapsizey + y].totalcal = tmpfirstmap.totalcal;
    map[x * mapsizey + y].cocon = tmpfirstmap.cocon;
    map[x * mapsizey + y].calperc = tmpfirstmap.calperc;
    map[x * mapsizey + y].ignitionpoint = tmpfirstmap.ignitionpoint;
    map[x * mapsizey + y].fuellevel = tmpfirstmap.fuellevel;
    map[x * mapsizey + y].calperf = tmpfirstmap.calperf;
    map[x * mapsizey + y].burnspeed = tmpfirstmap.burnspeed;
    map[x * mapsizey + y].block = tmpfirstmap.block;

  }
}

/* Updates the map. */
void updatemap()
{
  int r,rcount;
  long x,y;
  UPDATEMAP tmpupdatemap;
  char checksum2; /* The name checksum is already taken. */
  
  totsend(sockfd,"getmap;",10,0);

  while (1){
    r = 0;
    rcount = 0;
    /* recv the struct and put it where it belongs. */
    r = totrecv(sockfd,&tmpupdatemap,sizeof(UPDATEMAP),0);

    /* Check if this is the last packet. */
    if (tmpupdatemap.neto.type != TYPE_DATA)
      break;

    /* Now check the checksum. We do this after checking for TYPE_DONE because
       the TYPE_DONE packet doesn't have a checksum. */
    checksum2 = tmpupdatemap.neto.checksum;
    tmpupdatemap.neto.checksum = 0;
    tmpupdatemap.neto.checksum =
      checksum(&tmpupdatemap,sizeof(UPDATEMAP));

    
    if (checksum2 != tmpupdatemap.neto.checksum){
      printf("Error! Checksums don't match2. Got %d Calculated %d\n",
	     (int)checksum2, (int)tmpupdatemap.neto.checksum);
      cleanexit(EXIT_FAILURE);
    }

    x = tmpupdatemap.neto.x;
    y = tmpupdatemap.neto.y;
    
    /* Copy the stuff in tmpupdatemap to the correct locations. */
    map[x * mapsizey + y].totalcal = tmpupdatemap.totalcal;
    map[x * mapsizey + y].fuellevel = tmpupdatemap.fuellevel;

  }
}

/* Updates the playerinfo. */
void updateplayerinfo()
{
  int r,rcount;
  PLAYERINFO tmpplayerinfo;
  char checksum2; /* The name checksum is already taken. */

  if (numplayers > 0){
    free(playerlist);
    playerlist = NULL;
    numplayers = 0;
  }

  totsend(sockfd,"getplayerinfo;",14,0);

  while (1){
    r = 0;
    rcount = 0;
    /* recv the struct and put it where it belongs. */
    r = totrecv(sockfd,&tmpplayerinfo,sizeof(PLAYERINFO),0);

    /* Check if this is the last packet. */
    if (tmpplayerinfo.neto.type != TYPE_DATA)
      break;

    /* Now check the checksum. We do this after checking for TYPE_DONE because
       the TYPE_DONE packet doesn't have a checksum. */
    checksum2 = tmpplayerinfo.neto.checksum;
    tmpplayerinfo.neto.checksum = 0;
    tmpplayerinfo.neto.checksum =
      checksum(&tmpplayerinfo,sizeof(PLAYERINFO));

    
    if (checksum2 != tmpplayerinfo.neto.checksum){
      printf("Error! Checksums don't match2. Got %d Calculated %d\n",
	     (int)checksum2, (int)tmpplayerinfo.neto.checksum);
      cleanexit(EXIT_FAILURE);
    }

    /* Increment numplayers. */
    numplayers++;

    /* Realloc playerlist. */
    playerlist = realloc(playerlist,numplayers * sizeof(PLAYERINFO));

    /* memcpy the info over. */
    memcpy(&playerlist[numplayers - 1],&tmpplayerinfo,sizeof(PLAYERINFO));
  }

  /* Set playerx and playery to the servers idea of where we are. */
  playerx = playerlist[ournum].x;
  playery = playerlist[ournum].y;

  have_playerlist = 1;
}

/* Logs in to a server. */
/* Returns 0 if successfull, 1 if not. */
int login2server(char *name){
  NETOVERHEAD tmpoverhead;
  PLAYERINFO  tmpplayerinfo;

  /* Tell the server we are logging in. */
  totsend(sockfd,"login;",6,0);

  /* Wait for ready packet. */
  totrecv(sockfd,&tmpoverhead,sizeof(NETOVERHEAD),0);

  if (tmpoverhead.type != TYPE_READY)
    return 1;

  /* Send our name. */
  strcpy(tmpplayerinfo.name,playername);
  totsend(sockfd,&tmpplayerinfo,sizeof(PLAYERINFO),0);

  /* Wait for done packet. */
  totrecv(sockfd,&tmpoverhead,sizeof(NETOVERHEAD),0);

  if (tmpoverhead.type == TYPE_DONE){
    ournum = tmpoverhead.x;
    return 0;
  }

  return 1;
}

/* Sends playerinfo to the server. Currently just sends the x and y pos but 
   that may change later. Much of this code is stolen from login2server, the
   protocol is identical. 
*/
void sendplayerinfo(){
  NETOVERHEAD tmpoverhead;
  PLAYERINFO  tmpplayerinfo;

  /* Warning! Hack alert! <bg>

     Because the server will currently accept anything we give it we have to 
     make sure we don't accidently wipe out the starting point it setup for us
     when we login. Because of that we wait untill we have gotten the 
     playerinfo once before sending any info to the server. 
  */
  if (!have_playerlist)
    return;

  /* Tell the server we are sending the playerinfo. */
  totsend(sockfd,"setplayerinfo;",14,0);

  /* Wait for ready packet. */
  totrecv(sockfd,&tmpoverhead,sizeof(NETOVERHEAD),0);

  if (tmpoverhead.type != TYPE_READY)
    goto SOMETHINGS_SCREWED;

  /* Send our x and y. */
  tmpplayerinfo.x = playerx;
  tmpplayerinfo.y = playery;
  tmpplayerinfo.num = ournum;
  totsend(sockfd,&tmpplayerinfo,sizeof(PLAYERINFO),0);

  /* Wait for done packet. */
  totrecv(sockfd,&tmpoverhead,sizeof(NETOVERHEAD),0);

  /* If we didn't get a TYPE_DONE packet something is screwed. Better exit. */
  if (tmpoverhead.type != TYPE_DONE){
  SOMETHINGS_SCREWED:
    fprintf(stderr,"Error! Something's really screwed! Server didn't send a TYPE_DONE packet after setplayerinfo.\n");
    cleanexit(EXIT_FAILURE);
  }
}

int recv2tmpbuf(){
  int r = -1;

  while (r < 1){
    r=recv(sockfd, tmpbuf, BLEN, 0);
  }

  return r;
}

void totsend(int sock,void *buff,int len,int op){
  int r = 0;
  int rlen = 0;
  int fl;

  fl = fcntl(sock,F_GETFL);

  /* Make the socket blocking. */
  fcntl(sock,F_SETFL,0);

  while (rlen < len){

    r = send(sock,(buff + rlen),len - rlen,op);

    if (r > 0)
      rlen += r;
  }

  fcntl(sock,F_SETFL,fl);
}

int totrecv(int sock,void *buff,int len,int op){
  int r = 0;
  int rlen = 0;
  int fl;

  fl = fcntl(sock,F_GETFL);

  /* Make the socket blocking. */
  fcntl(sock,F_SETFL,0);

  while (rlen < len){

    r = recv(sock,(buff + rlen),len - rlen,op);

    if (r > 0)
      rlen += r;
  }

  fcntl(sock,F_SETFL,fl);

  return rlen;
}
