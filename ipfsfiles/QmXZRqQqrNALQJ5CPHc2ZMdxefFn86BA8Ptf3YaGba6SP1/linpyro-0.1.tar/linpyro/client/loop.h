void mainloop();
void setuptimer();
void setupsignals();
void cleanexit(int exittype);

extern float updateinterval;
