#include "../shared/netpro.h"
void connect2server(char *server,int portnum); 
void syncnet(int force);
void resetnet();
void getfirstmap();
void updatemap();
void updateplayerinfo();
void sendplayerinfo();
int login2server(char *name);

extern long mapsizex,mapsizey;

extern char *conserver;
extern int conportnum;

extern char *playername;

extern int updatedplayerinfo;
