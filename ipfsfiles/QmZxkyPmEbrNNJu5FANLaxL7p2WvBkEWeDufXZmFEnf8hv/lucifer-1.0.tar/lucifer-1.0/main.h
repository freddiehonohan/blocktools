// Main header
// all extern vars go here

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <float.h>
#include <limits.h>
#include "mathfunc.h"

extern const unsigned char testpat[20];
extern int error;

// options
extern size_t mem2burn;

// used by burn storage
//
// numberofburndirs says how many seperate directorys BurnStorage
// should read/write files in and also says how big burndirlist is
//
// burndirlist is the actual array of dir's to burn
//
// storage2burn is how much storage BurnStorage should burn
extern int numberofburndirs;
extern size_t blocksize;
extern char **burndirlist;
extern size_t *storage2burn;


