extern void BurnStorage(int count);
extern void BurnStorageNoCheck(int count);
