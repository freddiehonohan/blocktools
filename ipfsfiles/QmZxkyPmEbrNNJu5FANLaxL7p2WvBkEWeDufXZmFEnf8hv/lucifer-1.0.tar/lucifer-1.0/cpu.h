// Header for the cpu burning
extern void BurnCPU(int count);
extern void BurnCPUNoCheck(int count);
