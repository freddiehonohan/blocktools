#include "main.h"
#include "fpu.h"

// note:
//
// All of this code needs lots of work. Because of percision problems it's
// rather tricky. I should make a function that will figure out max/min
// values for all of this stuff.

// does fpu calculations
void BurnFPU(int count)
{

  double a, b;
  long double ans;

  int i;

  for (i = 0; i < count; i++) {

    // get some random floating point numbers
    a = (double)rand(); /// (double)(rand() + 1) + (double)rand();
    b = (double)rand(); /// (double)(rand() + 1); //+ (double)rand();

    // first do the usual add, subtract, multiply and devide

    // add
    ans = (long double)(a + b);

    if (((ans - a) != b) || ((ans - b) != a)){
      error++;
      printf("Error! Added %f to %f and got %Lg\n",a,b,ans);
    }

    // subtract
    ans = (long double)(a - b);

    if ((ans + b) != a){
      error++;
      printf("Error! Subtracted %f from %f and got %Lg\n",b,a,ans);
    }

    // get some new, smaller, random floating point numbers
    a = (double)((float)a);
    b = (double)((float)b);

    // multiply
    ans = (long double)(a * b);

    if ((ans / b) != a){
      error++;
      printf("Error! Multiplied %f with %f and got %Lg\n",a,b,ans);
    }

    // devide
    ans = (long double)(a / b);

    if (((ans * b) < a - b) || ((ans * b) > a + b)){
      error++;
      printf("Error! Devided %f by %f and got %Lg\n",a,b,ans);
    }

  }

}

void BurnFPUNoCheck(int count)
{

  double a, b;
  long double ans;

  int i;

  for (i = 0; i < count; i++) {

    // get some random floating point numbers
    a = (double)rand() / (double)(rand() + 1) + (double)rand();
    b = (double)rand() / (double)(rand() + 1) + (double)rand();

    // first do the usual add, subtract, multiply and devide

    // add
    ans = (long double)(a + b);

    // subtract
    ans = (long double)(a - b);

    // get some new, smaller, random floating point numbers
    a = (double)((float)a);
    b = (double)((float)b);

    // multiply
    ans = (long double)(a * b);

    // devide
    ans = (long double)(a / b);

  }


}

