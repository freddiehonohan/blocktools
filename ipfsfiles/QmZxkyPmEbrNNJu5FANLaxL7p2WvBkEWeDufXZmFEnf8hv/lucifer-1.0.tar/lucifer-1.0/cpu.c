#include "main.h"
#include "cpu.h"

// does all sorts of integer stuff
void BurnCPU(int count)
{

  long int a, b;
  long int ans;
  long int max, min; // used for the rand_long function
  int i;

  // repeat this count times
  for(i = 0; i < count; i++){

  max = LONG_MAX / 2;
  min = LONG_MIN / 2;
  a = rand_long(max,min);
  b = rand_long(max,min);

  // add once because we want to check each answere
  ans = a + b;

  if (((ans - a) != b) || ((ans - b) != a)){
    error++;
    printf("Error! Added %ld to %ld and got %ld\n", a, b, ans);}

  // subtract
  ans = a - b;

  if ((ans + b) != a){
    error++;
    printf("Error! Subtracted %ld from %ld and got %ld\n", b, a, ans);}

  // make the numbers smaller so we don't get overflows
  max = sqrt(LONG_MAX);
  min = -max;
  a = rand_long(max,min);
  b = rand_long(max,min);

  // guard against devision by zero errors
  // remember that we're dealing with signed numbers, the number could be
  // -1 in which case a a++ wouldn't work
  if (a == 0)
  a++;
  if (b == 0)
  b++;

  // multiply
  ans = a * b;

  if ((ans / b) != a){
    error++;
    printf("Error! Multiplied %ld by %ld and got %ld\n", a, b, ans);}

  // devide
  ans = a / b;

  // because of the signed numbers we have to figure out how we
  // are going to check the result
  if (a > 0 && b > 0){

    // do normal checking
    if (((ans * b) < a - b) || ((ans * b) > a + b)){
      error++;
      printf("Error! Divided %ld by %ld and got %ld\n", a, b, ans);
      printf("%ld != %ld %ld\n",(ans * b),(a + (a % b)), (a % b));
    }

  }
  else if (a < 0 && b < 0){

    if (((ans * b) > a - b) || ((ans * b) < a + b)){
      error++;
      printf("Error! Divided %ld by %ld and got %ld\n", a, b, ans);
      printf("%ld != %ld %ld\n",(ans * b),(a + (a % b)), (a % b));
    }
  }
  else if ( a < 0 && b > 0){

    if (((ans * b) < a - b) || ((ans * b) > a + b)){
      error++;
      printf("Error! Divided %ld by %ld and got %ld\n", a, b, ans);
      printf("%ld != %ld %ld\n",(ans * b),(a + (a % b)), (a % b));
    }

  }
  else if ( a > 0 && b < 0){

    if (((ans * b) > a - b) || ((ans * b) < a + b)){
      error++;
      printf("Error! Divided %ld by %ld and got %ld\n", a, b, ans);
      printf("%ld != %ld %ld\n",(ans * b),(a + (a % b)), (a % b));
    }
  }

  }

}

// does all sorts of integer stuff
void BurnCPUNoCheck(int count)
{

  long int a, b;
  long int ans;
  int i;

  // repeat this count times
  for(i = 0; i < count; i++){

  a = (long int)rand();
  b = (long int)rand();

  // add 50 times
  // after all we're doing addition, not lots of rands
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;
  ans = a + b;

  // subtract 50 times
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;
  ans = a - b;

  // make the numbers smaller so we don't get overflows
  a = a / 300000;
  b = b / 300000;

  // guard against devision by zero errors
  // remember that we're dealing with signed numbers, the number could be
  // -1 in which case a a++ wouldn't work
  if (a == 0)
  a++;
  if (b == 0)
  b++;

  // multiply 50 times
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;
  ans = a * b;

  // devide 50 times
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;
  ans = a / b;

  }
}

