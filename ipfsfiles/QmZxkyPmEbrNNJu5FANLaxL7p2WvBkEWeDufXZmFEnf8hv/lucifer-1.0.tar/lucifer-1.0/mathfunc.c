#include "main.h"
#include "mathfunc.h"

// math functions for Lucifer

// random number functions

// A new rand() function. Just calls rand() and bounds the number thats
// returned.
//
// max is the maximum number we want, min is the minimum. Both can be plus
// or minus. Just don't make max smaller then min.
long int rand_long(long int max, long int min)
{

  long int seed;
  float difference; // this needs to be big, really big
  long int result;

  seed = (long int)rand();

  max++; // Need to do a bit of adjustment. Otherwise this function will
         // never return max.

  // do we need to bound seed?
  if (seed > max || seed < min){

    difference = (float)max - (float)min;

    result = min + (seed / (RAND_MAX / difference));

  }
  else{
    // just return seed
    result = seed;
  }

  return result;
}

/* cut out for now
// Same as above but returns a double and you can decide what level of
// precision you want.
//
// precision is a number telling you how many digits after the . you want.
double rand_double(double max, double min, int precision)
{

}
*/

