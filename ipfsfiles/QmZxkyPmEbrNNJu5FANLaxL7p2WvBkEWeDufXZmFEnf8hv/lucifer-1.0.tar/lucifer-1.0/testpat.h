extern const unsigned char testpat[];
