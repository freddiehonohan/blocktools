extern long int rand_long(long int max, long int min);
//extern double rand_double(double max, double min, int precision);
