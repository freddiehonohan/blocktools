/* Test patterns for storage.c and memory.c */

/* These are the bits in the array
Stuck bits  (11111111), (00000000)
Walking 1s  (10000000), (01000000), (00100000), (00010000), etc.
Walking 0s  (01111111), (10111111), (11011111), (11101111), etc.
Checkerboard (10101010)
Inverted Checkerboard (01010101)

Thanks goes to Scott Mueller for this list. */

const unsigned char testpat[20] = 
/* stuck bits */
{0x0, 0xff, 
 /* walking 1s */
0x80, 0x40, 0x20, 0x10, 0x8, 0x4, 0x2, 0x1,
 /* walking 0s */
0x7f, 0xbf, 0xdf, 0xef, 0xf7, 0xfb, 0xfd, 0xfe,
 /* checkerboard */
0xaa,
 /* inverse checkerboard */
 0x55};  

extern const unsigned char testpat[20];




