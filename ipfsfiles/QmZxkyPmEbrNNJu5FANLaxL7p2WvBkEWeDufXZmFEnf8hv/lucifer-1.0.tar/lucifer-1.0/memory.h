// Header for the memory burning
extern void BurnMemory(int count);
extern void BurnMemoryNoCheck(int count);
