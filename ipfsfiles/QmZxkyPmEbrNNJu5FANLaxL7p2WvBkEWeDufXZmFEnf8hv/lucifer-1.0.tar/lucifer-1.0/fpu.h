extern void BurnFPU(int count);
extern void BurnFPUNoCheck(int count);
