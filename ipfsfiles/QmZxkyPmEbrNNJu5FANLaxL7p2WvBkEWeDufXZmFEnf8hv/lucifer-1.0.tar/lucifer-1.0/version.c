const char version[] = "Lucifer 1.0";
