#include "main.h"
#include "storage.h"
#include "testpat.h"

char filename[] = "lucifer.tmp\0";

// burns in the storage, harddrives, floppy's, cdroms
//
// really just reads burndirlist and makes files of size storage2burn then
// writes random bytes to the files and checks them
void BurnStorage(int count)
{

  long unsigned int i = 0, i2 = 0;
  long unsigned int i3 = 0, i4 = 0;
  size_t r;
  FILE *fileptr;
  char *path;
  char tmpchar;
  unsigned char c1,c2;
  unsigned char *tmpblock;
  unsigned char *compblock;
  static int testpati = 0;
 
  for (i = 0; i < count; i++){

    // this loops through all of the different dir's
    for (i2 = 0; i2 < numberofburndirs; i2++){

      // get the path to the new file
      path = malloc(sizeof(char) * (strlen(*(burndirlist + i2)) + strlen(filename)));
      if (!path) {
        printf("Error! Couldn't allocate variable path.\n");
        error++;
        return;
      }
      path = strcpy(path,*(burndirlist + i2));
      path = strcat(path,filename);

      // make the file and open it
      fileptr = fopen(path, "w");
      
      if (!fileptr) {
        printf("Error! Couldn't get fileptr.\n");
        error++;
        return;
	}

      // now for the actual burning

      // prepare tmpblock
      tmpchar = testpat[testpati];
      testpati++;
      if (testpati > 19) testpati = 0;
      tmpblock = (unsigned char *)malloc(sizeof(unsigned char) * blocksize);
      compblock = (unsigned char *)malloc(sizeof(unsigned char) * blocksize);

      for (i3 = 0; i3 < blocksize; i3++){
        *(tmpblock + i3) = tmpchar;
      }

      // now write tmpblock to the file storage2burn times
      for (i3 = 0; i3 < *(storage2burn + i2); i3++){
        r = fwrite((void *)tmpblock,(size_t)sizeof(char),blocksize,fileptr);
        if (r != blocksize){
          printf("Error! fwrite should have wrote %lu bytes but only wrote %lu bytes.\n",(long unsigned int)blocksize,(long unsigned int)r);
          error++;
        }
      }
      
      // seek to the start
      //if (fseek(fileptr,(long)1,SEEK_SET)){
      //  printf("Error! fseek to start of %s failed.\n",path);
      //  error++;
      //}

      // we need to reset compblock to make sure fread overwrote it
      // otherwise fread could have done nothing and the error might go
      // undetected
      for (i3 = 0; i3 < blocksize; i3++){
        *(compblock + i3) = ~tmpchar;
      }

      fileptr = freopen(path,"r",fileptr);

      // now check if they were written right
      for (i3 = 0; i3 < *(storage2burn + i2); i3++){
        r = fread(compblock,sizeof(unsigned char),blocksize,fileptr);

        if (r != blocksize){
          printf("Error! fread should have read %lu bytes but only read %lu bytes.\n",(long unsigned int)blocksize,(long unsigned int)r);
          error++;
        } 

        // compare compblock with tmpblock
        for (i4 = 0; i4 < blocksize; i4++){
          c1 = (unsigned char)*(tmpblock + i4);
          c2 = (unsigned char)*(compblock + i4);

          if (c1 != c2){
            printf("Error! Wrote %x but read %x\n",c1,c2);
            error++;
          }
        }
      }

      // close the file
      if (fclose(fileptr) == EOF) {
        printf("Error! Couldn't close file %s\n",path);
        error++;
      }

      // delete the file
      r = (size_t)remove(path);

      if (r != 0){
	printf("Error! Could delete %s",path);
      }

      // clean up after ourselves
      if (path) free(path);
      if (tmpblock) free(tmpblock);
      if (compblock) free(compblock);

    }

  }

}

void BurnStorageNoCheck(int count)
{
  long unsigned int i = 0, i2 = 0;
  long unsigned int i3 = 0;
  long unsigned int r;
  FILE *fileptr;
  char *path;
  char tmpchar;
  char *tmpblock;
  static int testpati = 0;
  
  for (i = 0; i < count; i++){

    // this loops through all of the different dir's
    for (i2 = 0; i2 < numberofburndirs; i2++){

      // get the path to the new file
      path = malloc(sizeof(char) * (strlen(*(burndirlist + i2)) + strlen(filename)));
      if (!path) {
        printf("Error! Couldn't allocate variable path.\n");
        error++;
        return;
      }
      path = strcpy(path,*(burndirlist + i2));
      path = strcat(path,filename);

      fileptr = malloc(sizeof(FILE));

      if (!fileptr) {
        printf("Error! Couldn't allocate fileptr.\n");
        error++;
        return;
      }

      // make the file
      fileptr = fopen(path, "wb");

      // now for the actual burning

      // prepare tmpblock
      tmpchar = testpat[testpati];
      testpati++;
      if (testpati > 19) testpati = 0;
      tmpblock = malloc(sizeof(char) * blocksize);

      for (i3 = 0; i3 < blocksize; i3++){
        *(tmpblock + i3) = tmpchar;
      }

      // now write tmpblock to the file storage2burn times
      for (i3 = 0; i3 < *(storage2burn + i2); i3++){
        r = fwrite(tmpblock,sizeof(char),blocksize,fileptr);
      }

      // close the file
      if (fclose(fileptr) == EOF) {
        printf("Error! Couldn't close file %s\n",path);
        error++;
      }

      // clean up after ourselves
      if (path) free(path);
      if (tmpblock) free(tmpblock);

    }

  }


}

