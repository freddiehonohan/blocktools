#include "main.h"
#include "memory.h"
#include "testpat.h"

// burns in the memory
void BurnMemory(int count)
{
  unsigned char *mem1;
  unsigned char randomchar;
  long unsigned int i;
  int a,b,c;
  static int testpati = 0;

  for (c = 0; c < count; c++){

  // this one is simple
  // just allocate some memory in mem1 fill it with random stuff and check
  mem1 = malloc(mem2burn);

  /* get a char from testpat */
  randomchar = testpat[testpati];
  testpati++;
  if (testpati > 19) testpati = 0;

  if (!mem1){
    printf("Couldn't allocate %lu bytes of memory.\n", (long unsigned int)mem2burn);
    error++;
    return;
  }

  // fill mem1 with random junk
  for (i = 0; i < mem2burn; i++){
    *(mem1 + i) = randomchar;
    }


  // compare mem1 with randomchar
  for (i = 0; i < mem2burn; i++){
    if ((*(mem1 + i)) != randomchar){
      error++;
      a = (int)*(mem1 + i);
      b = (int)randomchar;
      printf("Error! Byte is %x at location %p but should be %x\n",
      a, (mem1 + i), b);
    }
  }
  
  // if you don't do this you're garbage :)
  free(mem1);

  }
}

// burns in the memory
void BurnMemoryNoCheck(int count)
{
  unsigned char *mem1;
  unsigned char randomchar;
  long unsigned int i;
  int c;
  static int testpati = 0;
 
  for (c = 0; c < count; c++){

  // this one is simple
  // just allocate some memory in mem1 fill it with random stuff and check
  mem1 = malloc(mem2burn);

  /* get a char from testpat */
  randomchar = testpat[testpati];
  testpati++;
  if (testpati > 19) testpati = 0;

  if (!mem1){
    printf("Couldn't allocate %lu bytes of memory.\n", (long unsigned int)mem2burn);
    error++;
    return;
  }

  // fill mem1 with random junk
  for (i = 0; i < mem2burn; i++){
    *(mem1 + i) = randomchar;
    }

  // if you don't do this you're garbage :)
  free(mem1);

  }
}
